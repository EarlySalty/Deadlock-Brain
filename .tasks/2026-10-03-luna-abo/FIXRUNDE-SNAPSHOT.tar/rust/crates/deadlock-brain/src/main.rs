#![forbid(unsafe_code)]
#![allow(dead_code)]

use std::{
    collections::BTreeSet,
    fs,
    io::{self, ErrorKind, Read},
    path::PathBuf,
    process,
};

use anyhow::{anyhow, Context, Result};
use clap::{Args, Parser, Subcommand, ValueEnum};
use deadlock_brain_core::{
    ai::{extract_ai_text, AiClient, AiConfig, ChatCompletionRequest, ChatMessage},
    build_narration,
    config::{self, Settings},
    http::HttpClient,
};
use serde::Serialize;
use serde_json::{json, Value};
use sqlx::PgPool;
use std::os::unix::fs::OpenOptionsExt;

mod pg_entities;
mod pg_insights;
mod pg_patchnotes;
mod pg_steam_news;
mod steam_web_api;
mod wiki_refresh;

#[derive(Debug, Parser)]
#[command(name = "deadlock-brain")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Debug, Subcommand)]
enum Commands {
    #[command(
        about = "Stellt eine Frage ausschließlich über den typisierten brain-serve/BrainClient-Pfad."
    )]
    Answer(BrainAnswerArgs),
    #[command(
        about = "Zeigt das Abo-Modell und die lokalen Konfigurationspfade ohne Modellaufruf."
    )]
    AiModel,
    #[command(about = "Zeigt lokale DB- und Source-Counts.")]
    Status,
    #[command(about = "Baut einen kompakten Datenkontext fuer eine Entity-Frage.")]
    Context(EntityContextArgs),
    #[command(about = "Baut eine Patch-Timeline fuer eine Entity.")]
    Timeline(TimelineArgs),
    #[command(about = "Baut einen KI-tauglichen Review-Kontext ohne Modellaufruf.")]
    Review(ReviewArgs),
    #[command(
        name = "ask-context",
        about = "Baut ein vertrauenssortiertes Wissens-Buendel plus LLM-Prompt zu einer beliebigen Deadlock-Frage."
    )]
    AskContext(AskContextArgs),
    #[command(
        name = "review-build",
        about = "Berechnet eine Build-Anfrage und veröffentlicht sie als gekennzeichnetes Review-Build."
    )]
    ReviewBuild(ReviewBuildArgs),
    #[command(
        name = "publish-build-query",
        about = "Veröffentlicht eine ausdrücklich angeforderte Build-Variante nach der bestehenden Daten- und Mechanikprüfung."
    )]
    PublishBuildQuery(ReviewBuildArgs),
    #[command(about = "Fuehrt lokale Datenqualitaetschecks aus.")]
    Quality(PrettyArgs),
    #[command(about = "Erzeugt und pflegt die lokale Game-Wiki-Wissensschicht.")]
    Wiki {
        #[command(subcommand)]
        target: WikiCommands,
    },
    #[command(about = "Erzeugt mechanisch begründete Reasoner-Builds und Backtests.")]
    Reason {
        #[command(subcommand)]
        target: ReasonCommands,
    },
    #[command(about = "Lädt Populationsdaten, baut Aggregate und zeigt Held-Baselines.")]
    Population(dbrain_population::PopulationArgs),
    #[command(about = "Zeigt Rename-/Rework-Beziehungen aus Patchnotes.")]
    Lineage(LineageArgs),
    #[command(about = "Zeigt alte/entfernte Entities aus Patchnotes.")]
    Legacy(LegacyArgs),
    #[command(
        about = "Sucht Entities nach Typ/Name in der zentralen Postgres (brain.entities + brain.entity_aliases)."
    )]
    Entities(EntitiesArgs),
    #[command(
        about = "Erzeugt einen erklaerbaren Hero-Build-Vorschlag aus API-/Sheet-/Patchdaten."
    )]
    Build(BuildArgs),
    #[command(name = "build-context")]
    BuildContext(BuildContextArgs),
    #[command(name = "build-eval")]
    BuildEval(BuildEvalArgs),
    #[command(
        name = "build-spec",
        about = "Synthesize publishable build payload JSON from corpus and live data."
    )]
    BuildSpec(BuildSpecArgs),
    #[command(about = "Zeigt strukturierte Item-Daten aus der Deadlock Assets API.")]
    Item(ItemArgs),
    #[command(about = "Importiert und analysiert Build-Trainingsdaten.")]
    Learn {
        #[command(subcommand)]
        target: LearnCommands,
    },
    #[command(about = "Importiert und analysiert Player-Matches als Entscheidungs-Training.")]
    Player {
        #[command(subcommand)]
        target: PlayerCommands,
    },
    #[command(about = "Speichert oder listet persistente Analyse-Kontexte.")]
    Analysis {
        #[command(subcommand)]
        target: AnalysisCommands,
    },
    #[command(about = "Zieht Daten aus einer Quelle.")]
    Pull {
        #[command(subcommand)]
        source: PullCommands,
    },
    #[command(
        about = "Zieht alle Sheet-Tabs frisch und normalisiert Hero-Stats und Tab-Tabellen."
    )]
    RefreshSheet,
    #[command(about = "Erzeugt normalisierte Daten aus Snapshots.")]
    Normalize {
        #[command(subcommand)]
        target: NormalizeCommands,
    },
    #[command(about = "Erzeugt strukturierte Daten aus importierten Quellen.")]
    Parse {
        #[command(subcommand)]
        target: ParseCommands,
    },
    #[command(about = "Reichert strukturierte Daten an.")]
    Enrich {
        #[command(subcommand)]
        target: EnrichCommands,
    },
    #[command(
        name = "pg",
        about = "Synchronisiert Daten direkt in die zentrale Postgres-DB."
    )]
    Pg {
        #[command(subcommand)]
        target: PgCommands,
    },
    #[command(about = "Importiert kuratierte Insights in die zentrale Postgres-DB.")]
    Insights {
        #[command(subcommand)]
        target: InsightCommands,
    },
}

#[derive(Debug, Args)]
struct BrainAnswerArgs {
    #[arg(
        long,
        value_name = "JSON",
        help = "Normale Client-Konfiguration mit Endpunkt und Infisical-Referenz."
    )]
    client_config: PathBuf,
    #[arg(
        long,
        value_name = "LOOPBACK_URL",
        help = "Expliziter brain-serve-Endpunkt; sonst aus der Client-Konfiguration."
    )]
    endpoint: Option<String>,
    #[arg(
        long = "scope",
        value_name = "SCOPE",
        required = true,
        help = "Trusted scope binding; may be repeated."
    )]
    scopes: Vec<String>,
    #[arg(long, default_value_t = 8_000)]
    timeout_ms: u64,
    #[arg(long)]
    request_id: Option<String>,
    #[arg(long)]
    conversation_id: Option<String>,
    #[arg(help = "Question sent to brain-serve.")]
    question: String,
}

#[derive(Debug, Args)]
struct PrettyArgs {
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
}

#[derive(Debug, Args)]
struct EntitiesArgs {
    #[arg(
        long = "type",
        value_name = "TYPE",
        help = "Optionaler Entity-Typ-Filter (z.B. hero, item, ability)."
    )]
    entity_type: Option<String>,
    #[arg(
        long,
        value_name = "QUERY",
        help = "Suchbegriff (Teilstring in canonical_name oder Alias)."
    )]
    query: String,
}

#[derive(Debug, Args)]
struct EntityContextArgs {
    #[arg(help = "Hero, Item, Ability oder Alias.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 30)]
    limit_events: usize,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
}

#[derive(Debug, Args)]
struct TimelineArgs {
    #[arg(help = "Hero, Item, Ability oder Alias.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 2000)]
    limit_events: usize,
    #[arg(long, help = "Neueste Patches zuerst.")]
    descending: bool,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
}

#[derive(Debug, Args)]
struct ReviewArgs {
    #[arg(help = "Hero, Item, Ability oder Alias.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 80)]
    limit_events: usize,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
    #[arg(
        long = "prompt-only",
        help = "Nur den deutschen Prompt-Entwurf ausgeben."
    )]
    prompt_only: bool,
}

#[derive(Debug, Args)]
struct AskContextArgs {
    query: String,
    #[arg(long = "limit-events", default_value_t = 80)]
    limit_events: usize,
    #[arg(long = "include-unverified")]
    include_unverified: bool,
    #[arg(long = "max-claims", default_value_t = 12)]
    max_claims: usize,
    #[arg(long = "prompt-only")]
    prompt_only: bool,
    #[arg(long = "game-wiki-dir", value_name = "PATH")]
    game_wiki_dir: Option<PathBuf>,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct ReviewBuildArgs {
    #[arg(help = "Natürliche Build-Anfrage, zum Beispiel 'Warden Gun Build'.")]
    query: String,
    #[arg(long = "wait-seconds", default_value_t = 30)]
    wait_seconds: u64,
}

#[derive(Debug, Subcommand)]
enum WikiCommands {
    #[command(
        name = "rebuild",
        about = "Erzeugt game-wiki/ aus Deadlock-Data-Snapshots neu."
    )]
    Rebuild(WikiRebuildArgs),
    #[command(about = "Aktualisiert Quellen und veröffentlicht einen geprüften Wiki-Snapshot.")]
    Refresh(wiki_refresh::RefreshArgs),
}

#[derive(Debug, Subcommand)]
enum ReasonCommands {
    #[command(name = "build", about = "Baut einen Reasoner-Build für einen Helden.")]
    Build(ReasonBuildArgs),
    #[command(
        name = "patch-impact",
        about = "Zeigt die Wirkung des letzten Patches."
    )]
    PatchImpact(ReasonPatchImpactArgs),
    #[command(
        name = "backtest",
        about = "Vergleicht Reasoner-Builds mit Autoren-Builds."
    )]
    Backtest(ReasonBacktestArgs),
}

#[derive(Debug, Args)]
struct ReasonBuildArgs {
    #[arg(help = "Heldname oder Hero-ID.")]
    hero: String,
    #[arg(long = "no-ai")]
    no_ai: bool,
    #[arg(
        long,
        conflicts_with = "publish",
        help = "Trockenlauf ohne Reasoner-DB-Schreibzugriffe, auch für Read-only-Verbindungen."
    )]
    no_persist: bool,
    #[arg(long)]
    patch: Option<String>,
    #[arg(long)]
    publish: bool,
    #[arg(long)]
    json: bool,
    #[arg(long = "seed-path", value_name = "PATH")]
    seed_path: Option<PathBuf>,
}

#[derive(Debug, Args)]
struct ReasonPatchImpactArgs {
    #[arg(help = "Heldname oder Hero-ID.")]
    hero: String,
    #[arg(
        long,
        help = "Trockenlauf ohne Reasoner-DB-Schreibzugriffe, auch für Read-only-Verbindungen."
    )]
    no_persist: bool,
    #[arg(long)]
    patch: Option<String>,
    #[arg(long)]
    json: bool,
}

#[derive(Debug, Args)]
struct ReasonBacktestArgs {
    #[arg(
        long,
        help = "Trockenlauf ohne Reasoner-DB-Schreibzugriffe, auch für Read-only-Verbindungen."
    )]
    no_persist: bool,
    #[arg(long)]
    hero: Option<String>,
    #[arg(long)]
    patch: Option<String>,
    #[arg(long)]
    json: bool,
    #[arg(long = "seed-path", value_name = "PATH")]
    seed_path: Option<PathBuf>,
}

#[derive(Debug, Args)]
struct WikiRebuildArgs {
    #[arg(
        long,
        value_name = "PATH",
        help = "Zielverzeichnis, default repo-root/game-wiki."
    )]
    dir: Option<PathBuf>,
}

#[derive(Debug, Args)]
struct LineageArgs {
    #[arg(help = "Optionaler Hero, Item, Ability oder alter Name.")]
    query: Option<String>,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
    #[arg(long, default_value_t = 50)]
    limit: usize,
}

#[derive(Debug, Args)]
struct LegacyArgs {
    #[arg(help = "Optionaler alter Name.")]
    query: Option<String>,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
    #[arg(long, default_value_t = 50)]
    limit: usize,
}

#[derive(Debug, Args)]
struct BuildArgs {
    #[arg(help = "Hero-Name.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 80)]
    limit_events: usize,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
}

#[derive(Debug, Args)]
struct BuildContextArgs {
    hero: String,
    #[arg(long, value_enum)]
    playstyle: Option<BuildPlaystyle>,
}

#[derive(Debug, Args)]
struct BuildEvalArgs {
    hero: String,
    #[arg(long, value_enum)]
    playstyle: Option<BuildPlaystyle>,
}

#[derive(Debug, Args)]
struct BuildSpecArgs {
    hero: String,
    #[arg(
        long = "corpus-dir",
        value_name = "PATH",
        default_value = dbrain_builds::spec::DEFAULT_CORPUS_DIR
    )]
    corpus_dir: PathBuf,
}

#[derive(Debug, Args)]
struct ItemArgs {
    #[arg(help = "Item-Name.")]
    query: String,
    #[arg(long, help = "Kompakter menschenlesbarer Output statt JSON.")]
    pretty: bool,
}

#[derive(Debug, Subcommand)]
enum LearnCommands {
    #[command(
        name = "import-steam-builds",
        about = "Importiert GC/Steam Hero-Builds aus der Steam-Bot-DB."
    )]
    ImportSteamBuilds(ImportSteamBuildsArgs),
    #[command(name = "list-builds", about = "Listet importierte Trainings-Builds.")]
    ListBuilds(ListBuildsArgs),
    #[command(
        name = "analyze-build",
        about = "Lässt die KI einen importierten Build als Trainingsbeispiel analysieren."
    )]
    AnalyzeBuild(AnalyzeBuildArgs),
    #[command(
        name = "analyze-next",
        about = "Analysiert automatisch die naechsten noch offenen Trainings-Builds."
    )]
    AnalyzeNext(AnalyzeNextBuildsArgs),
}

#[derive(Debug, Args)]
struct ImportSteamBuildsArgs {
    #[arg(long, help = "Optional nur ein Hero.")]
    hero: Option<String>,
    #[arg(
        long,
        default_value_t = 0,
        help = "Steam Build-Sprache, default Englisch=0."
    )]
    language: i64,
    #[arg(long = "limit-per-hero", default_value_t = 10)]
    limit_per_hero: usize,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct ListBuildsArgs {
    #[arg(long)]
    hero: Option<String>,
    #[arg(long, default_value_t = 25)]
    limit: usize,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct AnalyzeBuildArgs {
    #[arg(help = "ID aus learned_builds.")]
    build_id: i64,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run")]
    dry_run: bool,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct AnalyzeNextBuildsArgs {
    #[arg(long, help = "Optional nur ein Hero.")]
    hero: Option<String>,
    #[arg(long, default_value_t = 5)]
    limit: usize,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run")]
    dry_run: bool,
    #[arg(long = "delay-seconds", default_value_t = 2.0)]
    delay_seconds: f64,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Subcommand)]
enum PlayerCommands {
    #[command(
        name = "list-matches",
        about = "Listet importierte Statlocker Player-Matches."
    )]
    ListMatches(PlayerListMatchesArgs),
    #[command(
        name = "match-context",
        about = "Baut einen modell-tauglichen Player-Match-Kontext ohne Aufruf."
    )]
    MatchContext(PlayerMatchContextArgs),
    #[command(
        name = "analyze-match",
        about = "Lässt die KI ein Player-Match als Entscheidungsbeispiel analysieren."
    )]
    AnalyzeMatch(PlayerAnalyzeMatchArgs),
    #[command(
        name = "analyze-demo-match",
        about = "Erstellt einen evidenzgebundenen Vollreport aus gespeicherter Demo-Evidenz."
    )]
    AnalyzeDemoMatch(PlayerAnalyzeDemoMatchArgs),
    #[command(
        name = "review-demo-report",
        about = "Speichert ein menschliches Review fuer einen Demo-Vollreport."
    )]
    ReviewDemoReport(PlayerReviewDemoReportArgs),
    #[command(
        name = "demo-calibration-status",
        about = "Zeigt den Review- und Kalibrierungsstand eines Spielers."
    )]
    DemoCalibrationStatus(PlayerDemoCalibrationStatusArgs),
    #[command(
        name = "analyze-next",
        about = "Analysiert automatisch die naechsten offenen Player-Matches."
    )]
    AnalyzeNext(PlayerAnalyzeNextArgs),
    #[command(
        name = "sync-matches",
        about = "Synchronisiert die Match-History eines Spielers aus der Deadlock API."
    )]
    SyncMatches(PlayerSyncMatchesArgs),
    #[command(
        name = "fetch-demo",
        about = "Laedt versionierte Match-Evidenz aus einer Deadlock-Demo."
    )]
    FetchDemo(PlayerFetchDemoArgs),
}

#[derive(Debug, Args)]
struct PlayerListMatchesArgs {
    #[arg(long = "account-id")]
    account_id: Option<String>,
    #[arg(long, default_value_t = 25)]
    limit: usize,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerMatchContextArgs {
    account_id: String,
    match_id: String,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerAnalyzeMatchArgs {
    account_id: String,
    match_id: String,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run")]
    dry_run: bool,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerAnalyzeDemoMatchArgs {
    account_id: String,
    match_id: String,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run")]
    dry_run: bool,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerReviewDemoReportArgs {
    note_id: i64,
    #[arg(long)]
    file: PathBuf,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerDemoCalibrationStatusArgs {
    account_id: String,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerAnalyzeNextArgs {
    #[arg(long = "account-id")]
    account_id: Option<String>,
    #[arg(long, default_value_t = 5)]
    limit: usize,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run")]
    dry_run: bool,
    #[arg(long = "delay-seconds", default_value_t = 2.0)]
    delay_seconds: f64,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerSyncMatchesArgs {
    account_id: String,
    #[arg(long = "hero-id", default_value_t = 18)]
    hero_id: u32,
    #[arg(long = "cache-ttl-seconds", default_value_t = 21_600)]
    cache_ttl_seconds: u64,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct PlayerFetchDemoArgs {
    account_id: String,
    match_id: String,
    #[arg(long = "hero-id", default_value_t = 18)]
    hero_id: u32,
    #[arg(long = "steam-id64", default_value_t = 76561198242034120)]
    steam_id64: u64,
    #[arg(long = "poll-interval-seconds", default_value_t = 5)]
    poll_interval_seconds: u64,
    #[arg(long = "timeout-seconds", default_value_t = 900)]
    timeout_seconds: u64,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Subcommand)]
enum AnalysisCommands {
    #[command(
        name = "save-review",
        about = "Speichert einen Review-Kontext ohne Modellaufruf."
    )]
    SaveReview(AnalysisSaveReviewArgs),
    #[command(
        name = "run-fireworks",
        aliases = ["run-minimax", "run-ai"],
        about = "Ruft die KI für einen Review-Kontext auf und speichert das Ergebnis."
    )]
    RunAi(AnalysisRunAiArgs),
    #[command(name = "list", about = "Listet gespeicherte Analyse-Notizen.")]
    List(AnalysisListArgs),
}

#[derive(Debug, Args)]
struct AnalysisSaveReviewArgs {
    #[arg(help = "Hero, Item, Ability oder Alias.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 80)]
    limit_events: usize,
    #[arg(long = "result-text", help = "Optionaler fertiger Analyse-Text.")]
    result_text: Option<String>,
    #[arg(long, help = "Optionaler Modellname fuer fertige Analyse.")]
    model: Option<String>,
    #[arg(long)]
    confidence: Option<f64>,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct AnalysisRunAiArgs {
    #[arg(help = "Hero, Item, Ability oder Alias.")]
    query: String,
    #[arg(long = "limit-events", default_value_t = 80)]
    limit_events: usize,
    #[arg(long)]
    model: Option<String>,
    #[arg(long = "max-completion-tokens")]
    max_completion_tokens: Option<u64>,
    #[arg(long)]
    temperature: Option<f64>,
    #[arg(long = "top-p")]
    top_p: Option<f64>,
    #[arg(long = "dry-run", help = "Baut nur die KI-Anfrage ohne Modellaufruf.")]
    dry_run: bool,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Args)]
struct AnalysisListArgs {
    #[arg(long)]
    query: Option<String>,
    #[arg(long, default_value_t = 25)]
    limit: usize,
    #[arg(long)]
    pretty: bool,
}

#[derive(Debug, Subcommand)]
enum PullCommands {
    #[command(about = "Zieht Deadlock Assets API Daten.")]
    Assets(PullAssetsArgs),
    #[command(
        name = "deadlock-data",
        about = "Zieht trusted deadlock-data aus GitHub."
    )]
    DeadlockData(PullDeadlockDataArgs),
    #[command(name = "build-data")]
    BuildData(PullBuildDataArgs),
    #[command(about = "Importiert bestehende Patchnotes aus der zentralen Bot-DB.")]
    Patchnotes(PullPatchnotesArgs),
    #[command(about = "Zieht oeffentliche Threads aus dem Deadlock-Forum anhand der Sitemap.")]
    Forum(PullForumArgs),
    #[command(about = "Zieht öffentliche Threads und Kommentare aus Reddit-Subreddits.")]
    Reddit(PullRedditArgs),
    #[command(about = "Zieht gezielt Statlocker WPA-/Leaderboard-Daten.")]
    Statlocker(Box<PullStatlockerArgs>),
}

#[derive(Debug, Args)]
struct PullAssetsArgs {
    #[arg(
        long,
        action = clap::ArgAction::Append,
        value_parser = [
            "items",
            "heroes",
            "heroes_all",
            "ranks",
            "colors",
            "build_tags",
            "npc_units",
        ],
        help = "Endpoint auswaehlen. Mehrfach nutzbar. Default: items/heroes."
    )]
    kind: Vec<String>,
}

#[derive(Debug, Args)]
struct PullDeadlockDataArgs {
    #[arg(
        long = "repo-dir",
        help = "Lokaler Cache. Standard: data/external/deadlock-data."
    )]
    repo_dir: Option<PathBuf>,
    #[arg(long, help = "Vollständiger Commitpin. Benötigt Parserrevision.")]
    commit: Option<String>,
    #[arg(
        long = "no-git-update",
        help = "Kompatibilitätsflag; Gitimporte lesen grundsätzlich nur lokal gepinnte Objekte."
    )]
    no_git_update: bool,
    #[arg(
        long,
        help = "Versionierte JSON-Quellenpins. Keine Pin-Overrides bei Configdatei."
    )]
    source_config: Option<PathBuf>,
    #[arg(
        long,
        help = "Nur lokale Pin-Konfiguration prüfen; keine Datenbank und keine Writes."
    )]
    check_config: bool,
    #[arg(long, help = "Explizite Parserrevision.")]
    parser_revision: Option<String>,
    #[arg(skip)]
    resolved: Option<Box<dbrain_sources::PullDeadlockDataOptions>>,
}

impl PullDeadlockDataArgs {
    fn resolve(&self, settings: &Settings) -> Result<dbrain_sources::PullDeadlockDataOptions> {
        if [
            "DBRAIN_SOURCE_PINS_CONFIG",
            "DBRAIN_DEADLOCK_DATA_COMMIT",
            "DBRAIN_DEADLOCK_DATA_PARSER_REVISION",
        ]
        .iter()
        .any(|name| std::env::var_os(name).is_some())
        {
            anyhow::bail!("environment pin overrides are unsupported; use explicit --source-config or CLI pins");
        }
        let source_config = self.source_config.clone();
        let pin = if let Some(path) = source_config {
            if self.commit.is_some() || self.parser_revision.is_some() {
                anyhow::bail!("source-config cannot be combined with CLI pin overrides; edit the explicit configuration instead");
            }
            dbrain_sources::source_pins::SourcePins::read(&path)?.deadlock_data
        } else {
            dbrain_sources::source_pins::DeadlockDataPin {
                commit: self.commit.clone().context(
                    "deadlock-data requires --source-config or --commit; never implicit HEAD",
                )?,
                parser_revision: self
                    .parser_revision
                    .clone()
                    .context("deadlock-data requires --parser-revision")?,
                schema_version: None,
                data_version: None,
            }
        };
        let options = dbrain_sources::PullDeadlockDataOptions {
            repo_dir: self
                .repo_dir
                .clone()
                .unwrap_or_else(|| settings.data_dir.join("external/deadlock-data")),
            pin,
            update_repo: false,
        };
        let _legacy_no_git_update = self.no_git_update;
        dbrain_sources::deadlock_data::preflight(&options)?;
        Ok(options)
    }
}

#[derive(Debug, Args)]
struct PullBuildDataArgs {
    #[arg(long)]
    hero: String,
}

#[derive(Debug, Args)]
struct PullPatchnotesArgs {}

#[derive(Debug, Args)]
struct PullForumArgs {
    #[arg(
        long = "sitemap-url",
        default_value = "https://forums.playdeadlock.com/sitemap.xml"
    )]
    sitemap_url: String,
    #[arg(
        long,
        default_value_t = 25,
        help = "0 bedeutet ohne Limit; fuer Backfills besser kleine Wellen nutzen."
    )]
    limit: usize,
    #[arg(long = "delay-seconds", default_value_t = 1.0)]
    delay_seconds: f64,
    #[arg(long = "cache-ttl-seconds", default_value_t = 86_400)]
    cache_ttl_seconds: u64,
    #[arg(
        long = "refresh-existing",
        help = "Bereits gespeicherte Thread-IDs erneut abrufen."
    )]
    refresh_existing: bool,
}

#[derive(Debug, Args)]
struct PullRedditArgs {
    #[arg(long = "subreddit", help = "Mehrfach nutzbar. Default: Deadlock.")]
    subreddit: Vec<String>,
    #[arg(
        long,
        default_value_t = 25,
        help = "Limit pro Subreddit; 0 bedeutet ohne Limit."
    )]
    limit: usize,
    #[arg(long = "delay-seconds", default_value_t = 2.0)]
    delay_seconds: f64,
    #[arg(long = "cache-ttl-seconds", default_value_t = 86_400)]
    cache_ttl_seconds: u64,
    #[arg(
        long = "refresh-existing",
        help = "Bereits gespeicherte Thread-IDs erneut abrufen."
    )]
    refresh_existing: bool,
}

#[derive(Debug, Args)]
struct PullStatlockerArgs {
    #[arg(
        long,
        action = clap::ArgAction::Append,
        value_parser = [
            "wpa-patches",
            "wpa-items",
            "leaderboard",
            "player-profile",
            "player-matches",
            "match-detail",
            "player-build-analysis",
            "leaderboard-player-matches",
        ],
        help = "Mehrfach nutzbar. Default: wpa-patches, wpa-items, leaderboard."
    )]
    kind: Vec<String>,
    #[arg(
        long,
        help = "z.B. patch_129989 oder 129989. Default: neuester Statlocker-WPA-Patch."
    )]
    patch: Option<String>,
    #[arg(
        long,
        default_value = "all",
        help = "all oder Hero-Name, z.B. Mo & Krill."
    )]
    hero: String,
    #[arg(long = "min-sample-size", default_value_t = 500)]
    min_sample_size: u64,
    #[arg(long, default_value = "rank_10,rank_11")]
    rank: String,
    #[arg(long = "leaderboard-page", default_value_t = 1)]
    leaderboard_page: u64,
    #[arg(long = "leaderboard-page-size", default_value_t = 100)]
    leaderboard_page_size: u64,
    #[arg(
        long = "account-id",
        help = "Statlocker/Steam accountId fuer Player-Endpunkte."
    )]
    account_id: Option<String>,
    #[arg(long = "match-id", help = "Match-ID fuer Matchdetail-Endpunkt.")]
    match_id: Option<String>,
    #[arg(long = "hero-id", help = "Hero-ID fuer Player-Build-Analysis.")]
    hero_id: Option<String>,
    #[arg(long = "players-from-leaderboard", default_value_t = 5)]
    players_from_leaderboard: u64,
    #[arg(long = "matches-per-player", default_value_t = 6)]
    matches_per_player: u64,
    #[arg(long = "include-match-details")]
    include_match_details: bool,
    #[arg(long = "include-build-analysis")]
    include_build_analysis: bool,
    #[arg(long = "game-mode", value_enum, default_value_t = GameMode::All)]
    game_mode: GameMode,
    #[arg(long = "delay-seconds", default_value_t = 1.0)]
    delay_seconds: f64,
    #[arg(long = "cache-ttl-seconds", default_value_t = 21600)]
    cache_ttl_seconds: u64,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum GameMode {
    All,
    Standard,
    Brawl,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum BuildPlaystyle {
    Weapon,
    Spirit,
    Tank,
}

impl BuildPlaystyle {
    fn as_str(self) -> &'static str {
        match self {
            Self::Weapon => "weapon",
            Self::Spirit => "spirit",
            Self::Tank => "tank",
        }
    }
}

#[derive(Debug, Subcommand)]
enum NormalizeCommands {
    #[command(about = "Baut entities und entity_aliases.")]
    Entities(NormalizeEntitiesArgs),
    #[command(
        name = "sheet-stats",
        about = "Baut normalisierte Hero-Stats aus dem Google Sheet."
    )]
    SheetStats(NormalizeSheetStatsArgs),
    #[command(
        name = "sheet-tabs",
        about = "Baut normalisierte Tabellen fuer Hero-Rankings, Boons/AP und Raw-Heroes."
    )]
    SheetTabs(NormalizeSheetTabsArgs),
    #[command(
        name = "resolve-gaps",
        about = "Loest offene Entity-Luecken konservativ neu auf."
    )]
    ResolveGaps(ResolveGapsArgs),
}

#[derive(Debug, Args)]
struct NormalizeEntitiesArgs {
    #[arg(long, help = "Loescht normalisierte Entities vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct NormalizeSheetStatsArgs {
    #[arg(long, help = "Loescht Sheet-Stat-Tabellen vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct NormalizeSheetTabsArgs {
    #[arg(long, help = "Loescht Tab-Tabellen vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct ResolveGapsArgs {
    #[arg(
        long = "dry-run",
        help = "Nur Report erzeugen, keine DB-Aenderungen schreiben."
    )]
    dry_run: bool,
}

#[derive(Debug, Subcommand)]
enum ParseCommands {
    #[command(about = "Parst Patchnotes zu patch_events.")]
    Patchnotes(ParsePatchnotesArgs),
    #[command(
        name = "forum-claims",
        about = "Parst Forum-Posts zu historischen, quarantined Claims."
    )]
    ForumClaims(ParseForumClaimsArgs),
    #[command(
        name = "reddit-claims",
        about = "Parst Reddit-Posts zu historischen, quarantined Claims."
    )]
    RedditClaims(ParseRedditClaimsArgs),
}

#[derive(Debug, Args)]
struct ParsePatchnotesArgs {
    #[arg(long, help = "Loescht patch_events vorher neu.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct ParseForumClaimsArgs {
    #[arg(long, help = "Loescht forum_claims vorher neu.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct ParseRedditClaimsArgs {
    #[arg(
        long,
        help = "Löscht nur Reddit-Claims (ingest_source=reddit) vorher neu."
    )]
    rebuild: bool,
}

#[derive(Debug, Subcommand)]
enum EnrichCommands {
    #[command(name = "patch-events", about = "Baut Details aus patch_events.")]
    PatchEvents(EnrichPatchEventsArgs),
    #[command(about = "Baut Rename-/Rework-Lineage aus patch_events.")]
    Lineage(EnrichLineageArgs),
    #[command(
        name = "legacy-entities",
        about = "Baut alte/entfernte Entities aus patch_events."
    )]
    LegacyEntities(EnrichLegacyEntitiesArgs),
    #[command(
        name = "patch-impact",
        about = "Analysiert die Patch-Entwicklung von Entities."
    )]
    PatchImpact(PatchImpactArgs),
    #[command(name = "meta-trends", about = "Analysiert aktuelle Meta-Trends.")]
    MetaTrends,
}

#[derive(Debug, Args)]
struct EnrichPatchEventsArgs {
    #[arg(long, help = "Loescht Enrichments vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct EnrichLineageArgs {
    #[arg(long, help = "Loescht Lineage vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct EnrichLegacyEntitiesArgs {
    #[arg(long, help = "Loescht Legacy-Entities vorher.")]
    rebuild: bool,
}

#[derive(Debug, Args)]
struct PatchImpactArgs {
    #[arg(long, help = "Optional: Beschraenken auf diesen Hero.")]
    hero: Option<String>,
    #[arg(
        long,
        default_value_t = 10,
        help = "Anzahl der abzuarbeitenden Entities."
    )]
    limit: usize,
    #[arg(
        long = "dry-run",
        help = "Nur Prompt/Request bauen (benoetigt --hero), kein Modellaufruf."
    )]
    dry_run: bool,
}

#[derive(Debug, Subcommand)]
enum PgCommands {
    #[command(
        name = "import-steam-news",
        about = "Importiert offizielle Steam-News-Patches direkt nach brain.* in Postgres."
    )]
    ImportSteamNews(PgSteamNewsArgs),
    #[command(
        name = "import-patchnote",
        about = "Importiert exakt einen Patchnote-Eintrag direkt nach brain.* in Postgres."
    )]
    ImportPatchnote(PgImportPatchnoteArgs),
}

#[derive(Debug, Subcommand)]
enum InsightCommands {
    #[command(
        name = "import-json",
        about = "Importiert ein Insight-JSON-Array nach brain.insight_records."
    )]
    ImportJson(InsightImportJsonArgs),
}

#[derive(Debug, Args)]
struct PgSteamNewsArgs {
    #[command(flatten)]
    ledger: LedgerAccessArgs,
    #[arg(long = "dsn-env", default_value = "DEADLOCK_CENTRAL_DSN")]
    dsn_env: String,
    #[arg(long, default_value_t = 1_422_450)]
    appid: u32,
    #[arg(long = "start-date", default_value = "2024-01-01")]
    start_date: String,
    #[arg(long, default_value_t = 500)]
    count: u32,
    #[arg(long = "cache-ttl-seconds", default_value_t = 900)]
    cache_ttl_seconds: u64,
    #[arg(
        long = "include-non-official",
        help = "Auch externe Steam-News-Feeds importieren; Standard ist nur steam_community_announcements."
    )]
    include_non_official: bool,
    #[arg(long = "gid", action = clap::ArgAction::Append, help = "Optional auf einzelne Steam-News-GIDs begrenzen.")]
    gids: Vec<String>,
    #[arg(
        long = "dry-run",
        help = "Kein fachlicher Import; Datenbankzugriff und Steam-Abrufjournal bleiben aktiv."
    )]
    dry_run: bool,
}

#[derive(Debug, Args)]
struct PgImportPatchnoteArgs {
    #[command(flatten)]
    ledger: LedgerAccessArgs,
    #[arg(long = "patch-id", help = "changelog_posts.id")]
    patch_id: i64,
    #[arg(long = "dsn-env", default_value = "DEADLOCK_CENTRAL_DSN")]
    dsn_env: String,
    #[arg(
        long = "dry-run",
        help = "Kein fachlicher Import; Datenbankzugriff und Steam-Abrufjournal bleiben aktiv."
    )]
    dry_run: bool,
}

#[derive(Debug, Args)]
struct LedgerAccessArgs {
    #[arg(long, default_value = "config/steam-ledger.json")]
    ledger_config: PathBuf,
    #[arg(long, default_value = "config/infisical.json")]
    infisical_config: PathBuf,
}

async fn ledger_for_pg(target: &PgCommands) -> Result<steam_web_api::SteamLedger> {
    let (args, caller) = match target {
        PgCommands::ImportSteamNews(args) => (&args.ledger, pg_steam_news::STEAM_LEDGER_CALLER),
        PgCommands::ImportPatchnote(args) => (&args.ledger, pg_patchnotes::STEAM_LEDGER_CALLER),
    };
    let path = args.ledger_config.clone();
    let config: steam_web_api::SteamLedgerConfig = tokio::task::spawn_blocking(move || {
        const LIMIT: u64 = 16 * 1024;
        let file = fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(path)
            .map_err(|_| anyhow!("Ledger-Konfiguration ist nicht lesbar"))?;
        if !file
            .metadata()
            .map_err(|_| anyhow!("Ledger-Konfiguration ist nicht prüfbar"))?
            .is_file()
        {
            anyhow::bail!("Ledger-Konfiguration muss eine normale Datei sein");
        }
        let mut bytes = Vec::new();
        file.take(LIMIT + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| anyhow!("Ledger-Konfiguration ist nicht lesbar"))?;
        if bytes.len() as u64 > LIMIT {
            anyhow::bail!("Ledger-Konfiguration ist zu groß");
        }
        serde_json::from_slice(&bytes).map_err(|_| anyhow!("Ledger-Konfiguration ist ungültig"))
    })
    .await
    .map_err(|_| anyhow!("Ledger-Konfiguration ist nicht verfügbar"))??;
    let values = tokio::time::timeout(
        std::time::Duration::from_secs(10),
        dl_token_secrets::values(&args.infisical_config),
    )
    .await
    .map_err(|_| anyhow!("Infisical antwortet nicht rechtzeitig"))?
    .map_err(|_| anyhow!("Infisical-Secretquelle ist nicht verfügbar"))?;
    steam_web_api::SteamLedger::from_snapshot(caller, &config, &values)
        .map_err(|_| anyhow!("Ledger-Konfiguration oder Infisical-Referenz ist ungültig"))
}

#[derive(Debug, Args)]
struct InsightImportJsonArgs {
    #[arg(
        long = "file",
        value_name = "PATH",
        help = "JSON-Datei; ohne Datei wird stdin gelesen."
    )]
    file: Option<PathBuf>,
    #[arg(long = "dsn-env", default_value = "DEADLOCK_CENTRAL_DSN")]
    dsn_env: String,
    #[arg(
        long = "dry-run",
        help = "Nur validieren und zaehlen, keine PG-Schreibzugriffe."
    )]
    dry_run: bool,
}

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct AnswerClientConfig {
    endpoint: String,
    infisical_config: PathBuf,
    secret_reference: String,
}

impl AnswerClientConfig {
    fn load(path: &std::path::Path) -> Result<Self> {
        const LIMIT: u64 = 16 * 1024;
        let file =
            fs::File::open(path).map_err(|_| anyhow!("Client-Konfiguration ist nicht lesbar"))?;
        if !file
            .metadata()
            .map_err(|_| anyhow!("Client-Konfiguration ist nicht prüfbar"))?
            .is_file()
        {
            anyhow::bail!("Client-Konfiguration muss eine normale Datei sein");
        }
        let mut bytes = Vec::new();
        file.take(LIMIT + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| anyhow!("Client-Konfiguration ist nicht lesbar"))?;
        if bytes.len() as u64 > LIMIT {
            anyhow::bail!("Client-Konfiguration ist zu groß");
        }
        let mut config: Self = serde_json::from_slice(&bytes)
            .map_err(|_| anyhow!("Client-Konfiguration ist ungültig"))?;
        if config.endpoint.trim().is_empty()
            || config.endpoint.len() > 2048
            || config.infisical_config.as_os_str().is_empty()
        {
            anyhow::bail!("Client-Konfiguration ist ungültig");
        }
        let mut name = config.secret_reference.bytes();
        if !name
            .next()
            .is_some_and(|byte| byte.is_ascii_uppercase() || byte == b'_')
            || !name.all(|byte| byte.is_ascii_uppercase() || byte.is_ascii_digit() || byte == b'_')
        {
            anyhow::bail!("Infisical-Secret-Referenz ist ungültig");
        }
        if !config.infisical_config.is_absolute() {
            config.infisical_config = path
                .parent()
                .unwrap_or_else(|| std::path::Path::new("."))
                .join(&config.infisical_config);
        }
        Ok(config)
    }

    fn token_until(&self, deadline: std::time::Instant) -> Result<zeroize::Zeroizing<String>> {
        if std::time::Instant::now() >= deadline {
            anyhow::bail!("Infisical antwortet nicht rechtzeitig");
        }
        let path = self.infisical_config.clone();
        let name = self.secret_reference.clone();
        let (sender, receiver) = std::sync::mpsc::sync_channel(1);
        std::thread::Builder::new()
            .name("brain-cli-secrets".into())
            .spawn(move || {
                let result = tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                    .map_err(|_| anyhow!("Infisical-Loader ist nicht verfügbar"))
                    .and_then(|runtime| {
                        runtime
                            .block_on(dl_token_secrets::values(&path))
                            .map_err(|_| anyhow!("Infisical-Secretquelle ist nicht verfügbar"))
                    })
                    .and_then(|values| {
                        values
                            .into_iter()
                            .find(|(key, _)| key == &name)
                            .map(|(_, token)| token)
                            .ok_or_else(|| anyhow!("Konfiguriertes Secret fehlt in Infisical"))
                    })
                    .and_then(|token| {
                        if token.is_empty()
                            || token.len() > 4096
                            || !token.bytes().all(|byte| byte.is_ascii_graphic())
                        {
                            Err(anyhow!("Konfiguriertes Secret ist ungültig"))
                        } else {
                            Ok(token)
                        }
                    });
                let _ = sender.send(result);
            })
            .map_err(|_| anyhow!("Infisical-Loader ist nicht verfügbar"))?;
        let result = receiver
            .recv_timeout(deadline.saturating_duration_since(std::time::Instant::now()))
            .map_err(|_| anyhow!("Infisical antwortet nicht rechtzeitig"))?;
        if std::time::Instant::now() >= deadline {
            anyhow::bail!("Infisical antwortet nicht rechtzeitig");
        }
        result
    }
}

async fn run_brain_answer(args: &BrainAnswerArgs) -> Result<()> {
    if !(1..=60_000).contains(&args.timeout_ms) {
        anyhow::bail!("Client-Timeout ist ungültig");
    }
    let deadline = std::time::Instant::now() + std::time::Duration::from_millis(args.timeout_ms);
    let config = AnswerClientConfig::load(&args.client_config)?;
    let endpoint = args.endpoint.as_deref().unwrap_or(&config.endpoint);
    // Validate the transport before retrieving a credential; this does not send a request.
    brain_client::AsyncBrainClient::new_local(
        endpoint,
        "endpoint-validation",
        std::time::Duration::from_millis(args.timeout_ms),
    )
    .map_err(|_| anyhow!("Brain-Endpunkt ist ungültig"))?;
    let scopes: BTreeSet<String> = args
        .scopes
        .iter()
        .map(|scope| scope.trim())
        .filter(|scope| !scope.is_empty())
        .map(ToOwned::to_owned)
        .collect();
    if scopes.is_empty() || scopes.len() != args.scopes.len() {
        return Err(anyhow!(
            "Scopes müssen explizit, nichtleer und eindeutig sein"
        ));
    }
    let nonce = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .context("Systemzeit liegt vor UNIX_EPOCH")?
        .as_nanos();
    let default_id = format!("brain-cli-{}-{nonce}", process::id());
    let request_id = args
        .request_id
        .clone()
        .unwrap_or_else(|| default_id.clone());
    let conversation_id = args
        .conversation_id
        .clone()
        .unwrap_or_else(|| default_id.clone());
    let query = brain_client::Query {
        request_id,
        conversation_id,
        text: args.question.clone(),
        domain: None,
        requested_scopes: scopes,
        profile: brain_client::AnswerProfile::Explain,
        patch: None,
        mode: None,
    };
    query.validate().context("ungültige Brain-Anfrage")?;
    let token = config.token_until(deadline)?;
    let remaining = deadline.saturating_duration_since(std::time::Instant::now());
    if remaining.is_zero() {
        anyhow::bail!("Brain-Anfrage überschreitet das Zeitbudget");
    }
    let client = brain_client::AsyncBrainClient::new_local(endpoint, &token, remaining)
        .context("BrainClient konnte nicht erstellt werden")?;
    let response = client
        .answer(&query)
        .await
        .context("brain-serve Anfrage fehlgeschlagen")?;
    print_json(&response)
}

fn command_is_read_only(command: &Commands) -> bool {
    match command {
        Commands::Context(_)
        | Commands::Timeline(_)
        | Commands::Review(_)
        | Commands::AskContext(_)
        | Commands::Lineage(_)
        | Commands::Legacy(_)
        | Commands::Entities(_) => true,
        Commands::Reason { target } => match target {
            ReasonCommands::Build(args) => args.no_persist,
            ReasonCommands::PatchImpact(args) => args.no_persist,
            ReasonCommands::Backtest(args) => args.no_persist,
        },
        _ => false,
    }
}

async fn pg_pool_for_command(command: &Commands) -> Result<PgPool> {
    if command_is_read_only(command) {
        deadlock_brain_core::pg::pg_pool_read_only().await
    } else {
        deadlock_brain_core::pg::pg_pool().await
    }
}

fn main() {
    if let Err(error) = run_from_cli() {
        eprintln!("{error:#}");
        process::exit(1);
    }
}

fn run_from_cli() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::AiModel => {
            let settings = config::load_settings()?;
            print_json(&json!({
                "provider": "openai_chatgpt_subscription",
                "model": settings.ai_model,
                "executable": std::env::current_exe()?,
                "project_root": settings.project_root,
                "ai_config": settings.project_root.join("config/bot.toml"),
                "settings_config": settings.project_root.join("config/bot.toml"),
                "infisical_config": settings.project_root.join("config/bot.toml"),
                "data_dir": settings.data_dir,
                "raw_dir": settings.raw_dir,
                "cache_dir": settings.cache_dir,
            }))
        }
        Commands::Population(args) => dbrain_population::run_population(args),
        command => {
            let runtime = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()?;
            runtime.block_on(run(Cli { command }))
        }
    }
}

async fn run(cli: Cli) -> Result<()> {
    let Cli { command } = cli;
    if let Commands::Answer(args) = &command {
        return run_brain_answer(args).await;
    }
    if let Commands::Wiki {
        target: WikiCommands::Refresh(args),
    } = &command
    {
        return print_json(&wiki_refresh::run(args).await?);
    }
    let settings = config::load_settings()?;
    if let Commands::Entities(args) = &command {
        let pool = pg_pool_for_command(&command).await?;
        return pg_entities::run(args, &pool).await;
    }
    let mut command = match command {
        Commands::Pg { target } => {
            let ledger = ledger_for_pg(&target).await?;
            // Alle `pg`-Befehle nutzen synchrone Crates (`postgres` bzw. der
            // blocking-HttpClient), die intern teils selbst einen Tokio-Runtime
            // starten. Direkt im async-Kontext aufgerufen wuerde das
            // "runtime within a runtime" paniken -> daher komplett auf einen
            // Blocking-Thread auslagern. HttpClient/Settings werden dort OWNED
            // gebaut, damit die Closure `Send + 'static` bleibt.
            let settings = settings.clone();
            return tokio::task::spawn_blocking(move || {
                fs::create_dir_all(&settings.cache_dir)?;
                let http = http_client(&settings)?;
                run_pg(&http, &ledger, target)
            })
            .await?;
        }
        Commands::Insights { target } => {
            // `insights import-json` schreibt ueber den synchronen `postgres`-Crate
            // und muss daher ebenfalls vom async-Runtime entkoppelt laufen.
            return tokio::task::spawn_blocking(move || run_insights(target)).await?;
        }
        other => other,
    };
    // Resolve once before side effects; the same immutable options reach the importer.
    if let Commands::Pull {
        source: PullCommands::DeadlockData(args),
    } = &mut command
    {
        let options = args.resolve(&settings)?;
        if args.check_config {
            return print_json(&json!({"valid":true,"source_pin":options.pin,"writes":false}));
        }
        args.resolved = Some(Box::new(options));
    }
    prepare_dirs(&settings)?;
    // Wissensabfragen und ausdrücklich persistenzfreie Reasoner-Läufe erzwingen
    // Read-only bereits beim Verbindungsaufbau.
    let pool = pg_pool_for_command(&command).await?;

    match command {
        Commands::Answer(_) => unreachable!("answer is handled before local DB initialization"),
        Commands::Status => print_status(&pool, &settings).await,
        Commands::Context(args) => {
            let result = dbrain_retrieval::build_entity_context(
                &pool,
                &args.query,
                usize_to_i64(args.limit_events),
            )
            .await?;
            if args.pretty {
                print_context(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::Timeline(args) => {
            let result = dbrain_retrieval::build_entity_timeline(
                &pool,
                &args.query,
                usize_to_i64(args.limit_events),
                !args.descending,
            )
            .await?;
            if args.pretty {
                print_timeline(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::Review(args) => {
            let result = dbrain_retrieval::build_review_context(
                &pool,
                &args.query,
                usize_to_i64(args.limit_events),
            )
            .await?;
            if args.prompt_only {
                println!(
                    "{}",
                    str_value(get(&result, "prompt_de")).unwrap_or_default()
                );
                Ok(())
            } else if args.pretty {
                print_review_context(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::AskContext(args) => {
            let result = dbrain_retrieval::ask_context(
                &pool,
                &args.query,
                &dbrain_retrieval::AskContextOptions {
                    limit_events: usize_to_i64(args.limit_events),
                    include_unverified: args.include_unverified,
                    max_claims: args.max_claims,
                    game_wiki_dir: args.game_wiki_dir.clone(),
                },
            )
            .await?;
            if args.prompt_only {
                println!("{}", str_value(get(&result, "prompt")).unwrap_or_default());
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::ReviewBuild(args) => run_requested_build(&pool, args, true).await,
        Commands::PublishBuildQuery(args) => run_requested_build(&pool, args, false).await,
        Commands::Quality(args) => {
            let result = dbrain_retrieval::run_quality_checks(&pool).await?;
            if args.pretty {
                print_quality_report(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::Wiki { target } => match target {
            WikiCommands::Refresh(args) => print_json(&wiki_refresh::run(&args).await?),
            WikiCommands::Rebuild(args) => {
                let dir = args
                    .dir
                    .unwrap_or_else(dbrain_retrieval::default_game_wiki_dir);
                let result = dbrain_retrieval::rebuild_game_wiki(&pool, &dir).await?;
                print_json(&result)
            }
        },
        Commands::Reason { target } => run_reason(&pool, &settings, target).await,
        Commands::Lineage(args) => {
            let rows = load_lineage(&pool, args.query.as_deref(), args.limit).await?;
            if args.pretty {
                print_lineage(&rows, args.query.as_deref());
                Ok(())
            } else {
                print_json(&json!({"query": args.query, "lineage": rows}))
            }
        }
        Commands::Legacy(args) => {
            let rows = load_legacy(&pool, args.query.as_deref(), args.limit).await?;
            if args.pretty {
                print_legacy(&rows, args.query.as_deref());
                Ok(())
            } else {
                print_json(&json!({"query": args.query, "legacy_entities": rows}))
            }
        }
        Commands::Build(args) => {
            let result =
                dbrain_learn::build_hero_build_context(&pool, &args.query, &[], args.limit_events)
                    .await?;
            if args.pretty {
                print_build_context(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::BuildContext(args) => {
            let playstyle = args.playstyle.map(BuildPlaystyle::as_str);
            let result = dbrain_builds::build_context(&pool, &args.hero, playstyle).await?;
            print_json(&result)
        }
        Commands::BuildEval(args) => run_build_eval(&pool, &settings, args).await,
        Commands::BuildSpec(args) => run_build_spec(&pool, &settings, args).await,
        Commands::Item(args) => {
            let result = dbrain_retrieval::build_item_context(&pool, &args.query).await?;
            if args.pretty {
                print_item_context(&result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        Commands::Learn { target } => run_learn(&settings, target).await,
        Commands::Player { target } => run_player(&settings, target).await,
        Commands::Analysis { target } => run_analysis(&pool, &settings, target).await,
        Commands::Pull { source } => run_pull(&pool, &settings, source).await,
        Commands::RefreshSheet => run_refresh_sheet(&pool, &settings).await,
        Commands::Normalize { target } => run_normalize(&pool, target).await,
        Commands::Parse { target } => run_parse(&pool, target).await,
        Commands::Enrich { target } => run_enrich(&pool, &settings, target).await,
        Commands::AiModel | Commands::Population(_) => {
            unreachable!("Population wird vor allgemeiner Pool-Ausfuehrung ausgefuehrt.")
        }
        Commands::Entities(_) => {
            unreachable!("PG-Entities werden vor allgemeiner Pool-Ausfuehrung ausgefuehrt.")
        }
        Commands::Pg { target: _ } => {
            unreachable!("PG-Commands werden vor allgemeiner Pool-Ausfuehrung ausgefuehrt.")
        }
        Commands::Insights { target: _ } => {
            unreachable!("PG-Insights werden vor allgemeiner Pool-Ausfuehrung ausgefuehrt.")
        }
    }
}

fn run_pg(
    http: &HttpClient,
    ledger: &steam_web_api::SteamLedger,
    target: PgCommands,
) -> Result<()> {
    match target {
        PgCommands::ImportSteamNews(args) => print_json(&pg_steam_news::import_steam_news(
            http,
            ledger,
            &pg_steam_news::ImportSteamNewsOptions {
                dsn_env: args.dsn_env,
                appid: args.appid,
                start_date: args.start_date,
                count: args.count,
                cache_ttl_seconds: args.cache_ttl_seconds,
                include_non_official: args.include_non_official,
                gids: args.gids,
                dry_run: args.dry_run,
            },
        )?),
        PgCommands::ImportPatchnote(args) => run_pg_patchnote(http, ledger, args),
    }
}

fn run_pg_patchnote(
    http: &HttpClient,
    ledger: &steam_web_api::SteamLedger,
    args: PgImportPatchnoteArgs,
) -> Result<()> {
    print_json(&pg_patchnotes::import_patchnote(
        http,
        ledger,
        &pg_patchnotes::ImportPatchnoteOptions {
            patch_id: args.patch_id,
            dsn_env: args.dsn_env,
            dry_run: args.dry_run,
        },
    )?)
}

fn run_insights(target: InsightCommands) -> Result<()> {
    match target {
        InsightCommands::ImportJson(args) => {
            let raw = read_json_input(args.file.as_ref())?;
            print_json(&pg_insights::import_insights_json(
                &raw,
                &pg_insights::ImportInsightOptions {
                    dsn_env: args.dsn_env,
                    dry_run: args.dry_run,
                },
            )?)
        }
    }
}

fn read_json_input(path: Option<&PathBuf>) -> Result<String> {
    if let Some(path) = path {
        return fs::read_to_string(path).map_err(Into::into);
    }
    let mut raw = String::new();
    io::stdin().read_to_string(&mut raw)?;
    Ok(raw)
}

async fn run_build_eval(pool: &PgPool, settings: &Settings, args: BuildEvalArgs) -> Result<()> {
    let playstyle = args.playstyle.map(BuildPlaystyle::as_str);
    let build_context = dbrain_builds::build_context(pool, &args.hero, playstyle).await?;
    let config = AiConfig::from_settings(settings);
    if !config.subscription_configured() {
        return print_json(&json!({
            "build_context": build_context,
            "notice": "Der lokale KI-Zugang ist nicht eingerichtet; die Beschreibung wird übersprungen."
        }));
    }

    let client = AiClient::new(config)?;
    let request = build_narration::build_narration_request(&build_context, client.config())?;
    let response = client.chat(&request)?;
    let narration = extract_ai_text(&response);
    let known_item_names = load_known_item_names(pool).await?;
    let validation =
        build_narration::validate_narration(&narration, &build_context, &known_item_names);
    print_json(&json!({
        "build_context": build_context,
        "narration": narration,
        "validation": validation
    }))
}

async fn run_build_spec(pool: &PgPool, settings: &Settings, args: BuildSpecArgs) -> Result<()> {
    let build_context = dbrain_builds::build_context(pool, &args.hero, None).await?;
    let corpus =
        dbrain_builds::spec::load_corpus_build_by_hero_id(&args.corpus_dir, build_context.hero_id)?;
    let understanding_path = args
        .corpus_dir
        .join("understanding")
        .join(format!("{}.md", corpus.hero));
    let mut warnings = Vec::new();
    let (understanding, understanding_found) = match fs::read_to_string(&understanding_path) {
        Ok(text) => (Some(text), true),
        Err(error) if error.kind() == ErrorKind::NotFound => {
            warnings.push(format!(
                "understanding missing: {}",
                understanding_path.display()
            ));
            (None, false)
        }
        Err(error) => return Err(error.into()),
    };

    let known_item_names = load_known_item_names(pool).await?;
    let candidates =
        dbrain_builds::spec::build_candidate_set(&build_context, &corpus, &known_item_names);
    let client = AiClient::from_settings(settings)?;
    if !client.config().subscription_configured() {
        return Err(anyhow!(
            "Der lokale OpenAI-Abo-Zugang fehlt; build-spec benötigt das konfigurierte Modell."
        ));
    }

    let request = ChatCompletionRequest::new(
        vec![
            ChatMessage::system(dbrain_builds::spec::BUILD_SPEC_SYSTEM_PROMPT),
            ChatMessage::user(dbrain_builds::spec::build_spec_user_prompt(
                &build_context.hero_name,
                understanding.as_deref(),
                &candidates.items,
                &build_context,
            )),
        ],
        client.config(),
    );
    let response = client.chat(&request)?;
    let llm_text = extract_ai_text(&response);
    let llm_spec = dbrain_builds::spec::parse_llm_spec_text(&llm_text)?;
    let ability_order = dbrain_builds::spec::ability_order_from_corpus(&corpus);
    let skill_order_found = ability_order.is_some();
    if !skill_order_found {
        warnings.push("skill_order missing in corpus build".to_string());
    }

    let mut assembled = dbrain_builds::spec::assemble_payload(
        build_context.hero_id,
        llm_spec,
        &candidates.name_to_id,
        ability_order.as_deref(),
    );
    warnings.append(&mut assembled.warnings);
    eprintln!(
        "build-spec: item_count={} understanding_found={} skill_order_found={}",
        candidates.items.len(),
        understanding_found,
        skill_order_found
    );
    for warning in warnings {
        eprintln!("warning: {warning}");
    }
    print_json(&assembled.payload)
}

async fn load_known_item_names(pool: &PgPool) -> Result<BTreeSet<String>> {
    let names = sqlx::query_scalar::<_, String>(
        "SELECT name FROM brain.item_catalog WHERE name IS NOT NULL AND name <> ''",
    )
    .fetch_all(pool)
    .await?;
    let mut set = BTreeSet::new();
    for name in names {
        let trimmed = name.trim();
        if !trimmed.is_empty() {
            set.insert(trimmed.to_string());
        }
    }
    Ok(set)
}

async fn run_learn(settings: &Settings, target: LearnCommands) -> Result<()> {
    let pool = deadlock_brain_core::pg::pg_pool().await?;
    match target {
        LearnCommands::ImportSteamBuilds(args) => {
            let result = dbrain_learn::learn_import_steam_builds(
                &pool,
                dbrain_learn::LearnImportSteamBuildsOptions {
                    hero: args.hero,
                    language: args.language,
                    limit_per_hero: usize_to_i64(args.limit_per_hero),
                },
            )
            .await?;
            if args.pretty {
                print_learn_result("import-steam-builds", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        LearnCommands::ListBuilds(args) => {
            let result = Value::Array(
                dbrain_learn::learn_list_builds(
                    &pool,
                    args.hero.as_deref(),
                    usize_to_i64(args.limit),
                )
                .await?,
            );
            if args.pretty {
                print_learn_result("list-builds", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        LearnCommands::AnalyzeBuild(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_learn::learn_analyze_build(
                &pool,
                dbrain_learn::LearnAnalyzeBuildOptions {
                    build_id: args.build_id,
                    config,
                    dry_run: args.dry_run,
                    include_request: true,
                },
            )
            .await?;
            if args.pretty {
                print_learn_result("analyze-build", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        LearnCommands::AnalyzeNext(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_learn::learn_analyze_next(
                &pool,
                dbrain_learn::LearnAnalyzeNextOptions {
                    hero: args.hero,
                    limit: usize_to_i64(args.limit),
                    config,
                    dry_run: args.dry_run,
                    delay_seconds: args.delay_seconds,
                },
            )
            .await?;
            if args.pretty {
                print_learn_result("analyze-next", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
    }
}

#[cfg(test)]
mod requested_build_tests {
    use super::*;
    #[test]
    fn requested_build_commands_separate_review_from_guarded_publication() {
        let regular = Cli::try_parse_from([
            "deadlock-brain",
            "publish-build-query",
            "--",
            "Warden Gun Build",
        ])
        .unwrap();
        assert!(matches!(regular.command, Commands::PublishBuildQuery(_)));
        let review =
            Cli::try_parse_from(["deadlock-brain", "review-build", "--", "Warden Gun Build"])
                .unwrap();
        assert!(matches!(review.command, Commands::ReviewBuild(_)));
    }
    #[test]
    fn requested_build_receipt_requires_real_completion() {
        assert_eq!(confirmed_publication("DONE", Some(123)), Some(123));
        for status in ["PENDING", "RUNNING", "FAILED", "CANCELLED", "BLOCKED"] {
            assert!(confirmed_publication(status, Some(123)).is_none());
        }
        for id in [None, Some(0), Some(-1)] {
            assert!(confirmed_publication("DONE", id).is_none());
        }
    }
}

fn confirmed_publication(status: &str, id: Option<i64>) -> Option<i64> {
    if status == "DONE" {
        id.filter(|id| *id > 0)
    } else {
        None
    }
}

async fn run_requested_build(pool: &PgPool, args: ReviewBuildArgs, review: bool) -> Result<()> {
    let ask = dbrain_retrieval::ask_context(
        pool,
        &args.query,
        &dbrain_retrieval::AskContextOptions {
            limit_events: 80,
            include_unverified: false,
            max_claims: 12,
            game_wiki_dir: None,
        },
    )
    .await?;
    if ask.pointer("/retrieval_meta/route").and_then(Value::as_str) != Some("build_reasoner") {
        return Err(anyhow!(
            "Die Anfrage wurde nicht als Build-Anfrage erkannt."
        ));
    }
    let mut build: dbrain_reasoner::BuildObject = serde_json::from_value(
        ask.get("build_context")
            .cloned()
            .ok_or_else(|| anyhow!("Der berechnete Build-Kontext fehlt."))?,
    )?;
    let alternative_variants = build.variants.len();
    if review {
        build.variants.clear();
        build.name = format!(
            "{} Brain Review {}",
            build.hero_name,
            chrono::Utc::now().format("%Y-%m-%d %H:%M")
        );
    } else if dbrain_reasoner::publish::validate_publish_input(&build).is_err() {
        // A user request authorizes creation, not bypassing publication quality gates.
        return print_json(&json!({
            "status":"BLOCKED", "task_id":null, "hero_build_id":null, "version":null,
            "hero_name":build.hero_name, "review":false, "core":[], "situations":[],
            "message": if alternative_variants > 0 {
                "Mehrere Buildvarianten passen. Bitte nenne den gewünschten Spielstil. Es wurde nichts veröffentlicht."
            } else {
                "Die aktuellen Daten reichen nicht für einen geprüften Build. Es wurde nichts veröffentlicht."
            }
        }));
    }
    let selected_family = build.family.as_ref().map(|family| family.label.clone());
    let task_id = if review {
        dbrain_reasoner::publish::enqueue_review_publish_task(pool, &build).await?
    } else {
        dbrain_reasoner::publish::enqueue_publish_task(pool, &build).await?
    };
    let deadline =
        tokio::time::Instant::now() + std::time::Duration::from_secs(args.wait_seconds.min(120));
    let (last_status, hero_build_id, version) = loop {
        let (status, result): (String, Option<Value>) = sqlx::query_as(
            "SELECT status, result FROM steam.steam_tasks WHERE id=$1 AND type='BUILD_PUBLISH_ORIGINAL'",
        )
        .bind(task_id)
        .fetch_one(pool)
        .await?;
        let hero_build_id = result
            .as_ref()
            .and_then(|value| value.pointer("/data/hero_build_id"))
            .and_then(Value::as_i64);
        let version = result
            .as_ref()
            .and_then(|value| value.pointer("/data/version"))
            .and_then(Value::as_i64);
        if matches!(status.as_str(), "DONE" | "FAILED" | "CANCELLED")
            || tokio::time::Instant::now() >= deadline
        {
            break (status, hero_build_id, version);
        }
        tokio::time::sleep(std::time::Duration::from_millis(500)).await;
    };
    if matches!(last_status.as_str(), "FAILED" | "CANCELLED") {
        return Err(anyhow!("Der Build konnte nicht veröffentlicht werden."));
    }
    let confirmed_id = confirmed_publication(&last_status, hero_build_id);
    if last_status == "DONE" && confirmed_id.is_none() {
        return Err(anyhow!(
            "Steam hat keine gültige Build-ID bestätigt. Die Veröffentlichung bleibt unbestätigt."
        ));
    }
    if !matches!(last_status.as_str(), "DONE" | "PENDING" | "RUNNING") {
        return Err(anyhow!("Der Veröffentlichungsstatus ist unbekannt."));
    }
    print_json(&json!({
        "status": last_status,
        "review": review,
        "task_id": task_id,
        "hero_build_id": confirmed_id,
        "version": version,
        "hero_id": build.hero_id,
        "hero_name": build.hero_name,
        "build_name": build.name,
        "selected_family": selected_family,
        "alternative_variants": alternative_variants,
        "core": build.core.iter().map(|item| json!({"item_id": item.item_id, "name": item.name})).collect::<Vec<_>>(),
        "situations": build.situations.iter().map(|block| json!({
            "label": block.label,
            "items": block.items.iter().map(|item| json!({"item_id": item.item_id, "name": item.name})).collect::<Vec<_>>()
        })).collect::<Vec<_>>()
    }))
}

async fn run_reason(pool: &PgPool, settings: &Settings, target: ReasonCommands) -> Result<()> {
    match target {
        ReasonCommands::Build(args) => {
            let mut config = dbrain_reasoner::ReasonerConfig {
                use_ai: !args.no_ai,
                ..Default::default()
            };
            if let Some(patch) = args.patch {
                config.patch_tag = patch;
            }
            let ai = config
                .use_ai
                .then(|| AiClient::from_settings(settings))
                .transpose()?;
            let ctx = dbrain_reasoner::ReasonerCtx {
                pool: pool.clone(),
                ai,
                config,
            };
            let seed_path = args.seed_path.unwrap_or_else(|| {
                config::path_env(
                    "DEADLOCK_REASONER_SEED_PATH",
                    settings
                        .project_root
                        .join(".tasks/2026-09-12-build-reasoner/referenz"),
                )
            });
            let build = dbrain_reasoner::reason_build_with_options(
                &ctx,
                &args.hero,
                dbrain_reasoner::ReasonerOptions {
                    seed_path: Some(&seed_path),
                    persist: !args.no_persist,
                },
            )
            .await?;
            let task_id = if args.publish {
                Some(dbrain_reasoner::publish::enqueue_publish_task(pool, &build).await?)
            } else {
                None
            };
            if args.json {
                if let Some(task_id) = task_id {
                    print_json(&json!({"build": build, "publish_task_id": task_id}))
                } else {
                    print_json(&build)
                }
            } else {
                print_reason_build(&build, task_id);
                Ok(())
            }
        }
        ReasonCommands::PatchImpact(args) => {
            let mut config = dbrain_reasoner::ReasonerConfig {
                use_ai: true,
                ..Default::default()
            };
            if let Some(patch) = args.patch {
                config.patch_tag = patch;
            }
            let ctx = dbrain_reasoner::ReasonerCtx {
                pool: pool.clone(),
                ai: Some(AiClient::from_settings(settings)?),
                config,
            };
            let report = dbrain_reasoner::reason_patch_impact_with_options(
                &ctx,
                &args.hero,
                dbrain_reasoner::ReasonerOptions {
                    persist: !args.no_persist,
                    ..Default::default()
                },
            )
            .await?;
            if args.json {
                print_json(&report)
            } else {
                print_reason_patch_impact(&report);
                Ok(())
            }
        }
        ReasonCommands::Backtest(args) => {
            let mut config = dbrain_reasoner::ReasonerConfig {
                use_ai: false,
                ..Default::default()
            };
            if let Some(patch) = args.patch.clone() {
                config.patch_tag = patch;
            }
            let ctx = dbrain_reasoner::ReasonerCtx {
                pool: pool.clone(),
                ai: None,
                config,
            };
            let seed_path = args.seed_path.unwrap_or_else(|| {
                config::path_env(
                    "DEADLOCK_REASONER_SEED_PATH",
                    settings
                        .project_root
                        .join(".tasks/2026-09-12-build-reasoner/referenz"),
                )
            });
            let report = dbrain_reasoner::reason_backtest_with_options(
                &ctx,
                dbrain_reasoner::BacktestFilter {
                    hero: args.hero,
                    patch_tag: args.patch,
                },
                dbrain_reasoner::ReasonerOptions {
                    seed_path: Some(&seed_path),
                    persist: !args.no_persist,
                },
            )
            .await?;
            if args.json {
                print_json(&report)
            } else {
                println!("{report}");
                Ok(())
            }
        }
    }
}

fn print_reason_build(build: &dbrain_reasoner::BuildObject, task_id: Option<i64>) {
    println!("{} ({})", build.name, build.patch_tag);
    println!("Kern:");
    for item in &build.core {
        println!("- {} [{:?}]", item.name, item.confidence);
    }
    for block in &build.situations {
        println!("{}:", block.label);
        for item in &block.items {
            println!("- {} [{:?}]", item.name, item.confidence);
        }
    }
    if !build.ability_order.is_empty() {
        println!("Skill-Order: {} Schritte", build.ability_order.len());
    }
    if !build.rationale.trim().is_empty() {
        println!("Warum: {}", build.rationale);
    }
    if let Some(task_id) = task_id {
        println!("Publish-Task: {task_id}");
    }
}

fn print_reason_patch_impact(report: &dbrain_reasoner::PatchImpactReport) {
    println!("{}: {}", report.hero_name, report.summary);
    for (item_id, shift) in &report.shifted_items {
        println!("- Item {item_id}: {shift:+.4}");
    }
}

async fn run_player(settings: &Settings, target: PlayerCommands) -> Result<()> {
    let pool = deadlock_brain_core::pg::pg_pool().await?;
    match target {
        PlayerCommands::ListMatches(args) => {
            let result = Value::Array(
                dbrain_learn::player_list_matches(
                    &pool,
                    args.account_id.as_deref(),
                    usize_to_i64(args.limit),
                )
                .await?,
            );
            if args.pretty {
                print_player_result("list-matches", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::MatchContext(args) => {
            let result =
                dbrain_learn::player_match_context(&pool, &args.account_id, &args.match_id).await?;
            if args.pretty {
                print_player_result("match-context", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::AnalyzeMatch(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_learn::player_analyze_match(
                &pool,
                dbrain_learn::PlayerAnalyzeMatchOptions {
                    account_id: args.account_id,
                    match_id: args.match_id,
                    config,
                    dry_run: args.dry_run,
                    include_request: true,
                },
            )
            .await?;
            if args.pretty {
                print_player_result("analyze-match", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::AnalyzeDemoMatch(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_learn::demo_analyze_match(
                &pool,
                dbrain_learn::DemoAnalyzeMatchOptions {
                    account_id: args.account_id,
                    match_id: args.match_id,
                    config,
                    dry_run: args.dry_run,
                    include_request: false,
                },
            )
            .await?;
            if args.pretty {
                if let Some(report) = get(&result, "rendered_report").and_then(Value::as_str) {
                    println!("{report}");
                } else {
                    println!(
                        "Demo-Report-Kontext bereit: {} Evidenzbelege, kein Modellaufruf.",
                        display_or(get(&result, "evidence_count"), "0")
                    );
                }
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::ReviewDemoReport(args) => {
            let review_text = fs::read_to_string(&args.file).map_err(|error| {
                anyhow!(
                    "Review-Datei {} konnte nicht gelesen werden: {error}",
                    args.file.display()
                )
            })?;
            let review: Value = serde_json::from_str(&review_text).map_err(|error| {
                anyhow!(
                    "Review-Datei {} enthaelt kein gueltiges JSON: {error}",
                    args.file.display()
                )
            })?;
            let result =
                dbrain_learn::save_demo_report_review(&pool, args.note_id, &review).await?;
            if args.pretty {
                println!(
                    "Demo-Review gespeichert: Snapshot {}, {} Korrekturen bei {} geprueften Entscheidungen, kritisch: {}.",
                    display_value(get(&result, "snapshot_id")),
                    display_or(get(&result["payload"], "correction_count"), "0"),
                    display_or(get(&result["payload"], "reviewed_decision_count"), "0"),
                    display_or(get(&result["payload"], "critical_error"), "false")
                );
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::DemoCalibrationStatus(args) => {
            let result = dbrain_learn::demo_calibration_status(&pool, &args.account_id).await?;
            if args.pretty {
                println!(
                    "Demo-Kalibrierung: bestanden: {}, Reports: {}/{}, saubere letzte Reports: {}/{}.",
                    display_or(get(&result, "passed"), "false"),
                    display_or(get(&result, "reviewed_report_count"), "0"),
                    display_or(get(&result, "minimum_reviewed_reports"), "5"),
                    display_or(get(&result, "qualifying_recent_reports"), "0"),
                    display_or(get(&result, "required_clean_recent_reports"), "3")
                );
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::AnalyzeNext(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_learn::player_analyze_next(
                &pool,
                dbrain_learn::PlayerAnalyzeNextOptions {
                    account_id: args.account_id,
                    limit: usize_to_i64(args.limit),
                    config,
                    dry_run: args.dry_run,
                    delay_seconds: args.delay_seconds,
                },
            )
            .await?;
            if args.pretty {
                print_player_result("analyze-next", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::FetchDemo(args) => {
            let http =
                http_client_async(settings.user_agent.clone(), settings.cache_dir.clone()).await?;
            let metadata = dbrain_sources::pull_match_metadata(
                &settings.raw_dir,
                &http,
                fetch_demo_match_metadata_options(&args),
            )
            .await?;
            let evidence = dbrain_sources::pull_demo_evidence(
                &settings.raw_dir,
                &http,
                fetch_demo_evidence_options(&args, &metadata)?,
            )
            .await?;
            let result = json!({
                "metadata": metadata,
                "demo_evidence": evidence,
            });
            if args.pretty {
                println!(
                    "Demo-Evidenz geladen: Match {}, {} Zeilen aus {} Queries.",
                    display_value(get(&evidence, "match_id")),
                    display_or(get(&evidence, "rows"), "0"),
                    array_len(get(&evidence, "queries"))
                );
                Ok(())
            } else {
                print_json(&result)
            }
        }
        PlayerCommands::SyncMatches(args) => {
            let http =
                http_client_async(settings.user_agent.clone(), settings.cache_dir.clone()).await?;
            let result = dbrain_sources::pull_player_match_history(
                &settings.raw_dir,
                &http,
                dbrain_sources::PullPlayerMatchHistoryOptions {
                    account_id: args.account_id,
                    hero_id: Some(args.hero_id),
                    cache_ttl_seconds: args.cache_ttl_seconds,
                },
            )
            .await?;
            if args.pretty {
                println!(
                    "Deadlock-API-Matches synchronisiert: {} gefunden, {} fuer den Hero gespeichert.",
                    display_or(get(&result, "api_rows"), "0"),
                    display_or(get(&result, "stored_rows"), "0")
                );
                Ok(())
            } else {
                print_json(&result)
            }
        }
    }
}

fn fetch_demo_match_metadata_options(
    args: &PlayerFetchDemoArgs,
) -> dbrain_sources::PullMatchMetadataOptions {
    dbrain_sources::PullMatchMetadataOptions {
        match_ids: vec![args.match_id.clone()],
        account_ids: vec![args.account_id.clone()],
        hero_ids: vec![args.hero_id.to_string()],
        include_player_items: true,
        include_player_info: true,
        include_player_stats: true,
        include_player_death_details: true,
        include_objectives: true,
        cache_ttl_seconds: 0,
    }
}

fn fetch_demo_evidence_options(
    args: &PlayerFetchDemoArgs,
    metadata: &Value,
) -> Result<dbrain_sources::PullDemoEvidenceOptions> {
    let player_slot = get(metadata, "target_player_slot")
        .and_then(Value::as_u64)
        .and_then(|value| u32::try_from(value).ok())
        .ok_or_else(|| anyhow!("Match-Metadaten enthalten keinen gueltigen Zielspieler-Slot."))?;
    Ok(dbrain_sources::PullDemoEvidenceOptions {
        account_id: args.account_id.clone(),
        match_id: args.match_id.clone(),
        hero_id: args.hero_id,
        steam_id64: args.steam_id64,
        player_slot,
        poll_interval_seconds: args.poll_interval_seconds,
        timeout_seconds: args.timeout_seconds,
    })
}

async fn run_analysis(pool: &PgPool, settings: &Settings, target: AnalysisCommands) -> Result<()> {
    match target {
        AnalysisCommands::SaveReview(args) => {
            let result = dbrain_retrieval::analysis_save_review_for_query(
                pool,
                &args.query,
                usize_to_i64(args.limit_events),
                args.result_text.as_deref(),
                args.model.as_deref(),
                args.confidence,
            )
            .await?;
            if args.pretty {
                print_analysis_result("save-review", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        AnalysisCommands::RunAi(args) => {
            let config = ai_config(
                settings,
                args.model,
                args.max_completion_tokens,
                args.temperature,
                args.top_p,
            );
            let result = dbrain_retrieval::analysis_run_ai(
                pool,
                &args.query,
                dbrain_retrieval::AnalysisRunAiOptions {
                    limit_events: usize_to_i64(args.limit_events),
                    config,
                    dry_run: args.dry_run,
                },
            )
            .await?;
            if args.pretty {
                print_analysis_result("run-fireworks", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
        AnalysisCommands::List(args) => {
            let result = dbrain_retrieval::analysis_list(
                pool,
                args.query.as_deref(),
                usize_to_i64(args.limit),
            )
            .await?;
            if args.pretty {
                print_analysis_result("list", &result);
                Ok(())
            } else {
                print_json(&result)
            }
        }
    }
}

async fn run_pull(pool: &PgPool, settings: &Settings, source: PullCommands) -> Result<()> {
    let http = http_client_async(settings.user_agent.clone(), settings.cache_dir.clone()).await?;
    match source {
        PullCommands::Assets(args) => {
            let result = dbrain_sources::pull_assets(
                &settings.raw_dir,
                &http,
                dbrain_sources::PullAssetsOptions { kinds: args.kind },
            )
            .await?;
            print_json(&result)
        }
        PullCommands::DeadlockData(args) => {
            let options = args
                .resolved
                .context("deadlock-data source pin preflight was not performed")?;
            let pull = dbrain_sources::deadlock_data::pull_deadlock_data_with_pool(
                pool,
                &settings.raw_dir,
                *options,
            )
            .await?;
            let patch_events = dbrain_normalize::parse_patchnotes(pool, false).await?;
            print_json(&json!({
                "pull": pull,
                "patch_events": patch_events,
            }))
        }
        PullCommands::BuildData(args) => {
            let result = dbrain_builds::sync_build_data(
                pool,
                dbrain_builds::BuildDataSyncOptions::new(args.hero, settings.user_agent.clone()),
            )
            .await?;
            print_json(&result)
        }
        PullCommands::Patchnotes(_) => {
            // Patchnotes werden direkt aus der zentralen Postgres
            // (`patchnotes`-Schema) gelesen.
            let result = dbrain_sources::pull_patchnotes(
                &settings.raw_dir,
                dbrain_sources::PullPatchnotesOptions,
            )
            .await?;
            print_json(&result)
        }
        PullCommands::Forum(args) => {
            let result = dbrain_sources::pull_forum(
                &settings.raw_dir,
                &http,
                dbrain_sources::PullForumOptions {
                    sitemap_url: args.sitemap_url,
                    limit: args.limit,
                    delay_seconds: args.delay_seconds,
                    cache_ttl_seconds: args.cache_ttl_seconds,
                    refresh_existing: args.refresh_existing,
                },
            )
            .await?;
            print_json(&result)
        }
        PullCommands::Reddit(args) => {
            let result = dbrain_sources::pull_reddit(
                &settings.raw_dir,
                &http,
                dbrain_sources::PullRedditOptions {
                    subreddits: args.subreddit,
                    limit: args.limit,
                    delay_seconds: args.delay_seconds,
                    cache_ttl_seconds: args.cache_ttl_seconds,
                    refresh_existing: args.refresh_existing,
                },
            )
            .await?;
            print_json(&result)
        }
        PullCommands::Statlocker(args) => {
            let result = dbrain_sources::pull_statlocker(
                &settings.raw_dir,
                &http,
                dbrain_sources::PullStatlockerOptions {
                    kinds: args.kind,
                    patch: args.patch,
                    hero: args.hero,
                    min_sample_size: args.min_sample_size,
                    rank: args.rank,
                    leaderboard_page: args.leaderboard_page,
                    leaderboard_page_size: args.leaderboard_page_size,
                    account_id: args.account_id,
                    match_id: args.match_id,
                    hero_id: args.hero_id,
                    players_from_leaderboard: args.players_from_leaderboard,
                    matches_per_player: args.matches_per_player,
                    include_match_details: args.include_match_details,
                    include_build_analysis: args.include_build_analysis,
                    game_mode: game_mode_value(args.game_mode),
                    delay_seconds: args.delay_seconds,
                    cache_ttl_seconds: args.cache_ttl_seconds,
                },
            )
            .await?;
            print_json(&result)
        }
    }
}

async fn run_refresh_sheet(pool: &PgPool, settings: &Settings) -> Result<()> {
    let http = http_client_async(settings.user_agent.clone(), settings.cache_dir.clone()).await?;
    let pull_wrapper = dbrain_sources::refresh_sheet(
        &settings.raw_dir,
        &http,
        dbrain_sources::RefreshSheetOptions {
            sheet_id: settings.sheet_id.clone(),
            gid: settings.sheet_gid.clone(),
        },
    )
    .await?;
    let pull = get(&pull_wrapper, "pull").cloned().unwrap_or(pull_wrapper);
    let entities = dbrain_normalize::normalize_entities(pool, true).await?;
    let stats = dbrain_normalize::normalize_sheet_stats(pool, true).await?;
    let tabs = dbrain_normalize::normalize_sheet_tabs(pool, true).await?;
    print_json(&json!({
        "pull": pull,
        "normalize_entities": entities,
        "normalize_sheet_stats": stats,
        "normalize_sheet_tabs": tabs,
    }))
}

async fn run_normalize(pool: &PgPool, target: NormalizeCommands) -> Result<()> {
    match target {
        NormalizeCommands::Entities(args) => {
            print_json(&dbrain_normalize::normalize_entities(pool, args.rebuild).await?)
        }
        NormalizeCommands::SheetStats(args) => {
            print_json(&dbrain_normalize::normalize_sheet_stats(pool, args.rebuild).await?)
        }
        NormalizeCommands::SheetTabs(args) => {
            print_json(&dbrain_normalize::normalize_sheet_tabs(pool, args.rebuild).await?)
        }
        NormalizeCommands::ResolveGaps(args) => {
            print_json(&dbrain_normalize::resolve_gaps(pool, args.dry_run).await?)
        }
    }
}

async fn run_parse(pool: &PgPool, target: ParseCommands) -> Result<()> {
    match target {
        ParseCommands::Patchnotes(args) => {
            print_json(&dbrain_normalize::parse_patchnotes(pool, args.rebuild).await?)
        }
        ParseCommands::ForumClaims(args) => {
            print_json(&dbrain_normalize::parse_forum_claims(pool, args.rebuild).await?)
        }
        ParseCommands::RedditClaims(args) => {
            print_json(&dbrain_normalize::parse_reddit_claims(pool, args.rebuild).await?)
        }
    }
}

async fn run_enrich(pool: &PgPool, settings: &Settings, target: EnrichCommands) -> Result<()> {
    match target {
        EnrichCommands::PatchEvents(args) => {
            print_json(&dbrain_enrich::build_patch_event_enrichments(pool, args.rebuild).await?)
        }
        EnrichCommands::Lineage(args) => {
            print_json(&dbrain_normalize::enrich_lineage(pool, args.rebuild).await?)
        }
        EnrichCommands::LegacyEntities(args) => {
            print_json(&dbrain_normalize::enrich_legacy_entities(pool, args.rebuild).await?)
        }
        EnrichCommands::PatchImpact(args) => {
            print_json(&run_patch_impact(pool, settings, args).await?)
        }
        EnrichCommands::MetaTrends => {
            let config = ai_config(settings, None, None, None, None);
            print_json(&dbrain_enrich::run_meta_trend_analysis(pool, &config).await?)
        }
    }
}

async fn run_patch_impact(
    pool: &PgPool,
    settings: &Settings,
    args: PatchImpactArgs,
) -> Result<Value> {
    let config = ai_config(settings, None, None, None, None);
    if args.dry_run {
        let Some(hero) = args.hero.as_deref() else {
            return Err(anyhow!("Fuer --dry-run muss --hero angegeben werden."));
        };
        let entity_type = entity_type_for_name(pool, hero).await?;
        let context = dbrain_enrich::build_patch_impact_context(pool, hero, &entity_type).await?;
        let request_info = dbrain_enrich::build_patch_impact_request(&context, &config)?;
        return Ok(json!({
            "dry_run": true,
            "prompt": request_info.prompt_text,
            "request": serde_json::to_value(&request_info.request)?,
        }));
    }
    if let Some(hero) = args.hero.as_deref() {
        let entity_type = entity_type_for_name(pool, hero).await?;
        let context = dbrain_enrich::build_patch_impact_context(pool, hero, &entity_type).await?;
        let request_info = dbrain_enrich::build_patch_impact_request(&context, &config)?;
        let client = AiClient::new(config.clone())?;
        let response = client.chat(&request_info.request)?;
        let result_text = extract_ai_text(&response);
        dbrain_enrich::save_patch_impact_note(
            pool,
            &context,
            &request_info.prompt_text,
            Some(&result_text),
            &config.model,
            "analysis_ready",
        )
        .await?;
        Ok(json!({"processed": 1, "success": 1, "failed": 0, "hero": hero}))
    } else {
        Ok(serde_json::to_value(
            dbrain_enrich::run_patch_impact_batch(pool, &config, args.limit).await?,
        )?)
    }
}

async fn entity_type_for_name(pool: &PgPool, name: &str) -> Result<String> {
    let value = sqlx::query_scalar::<_, String>(
        "SELECT entity_type FROM brain.entities WHERE canonical_name = $1 LIMIT 1",
    )
    .bind(name)
    .fetch_optional(pool)
    .await?;
    Ok(value.unwrap_or_else(|| "hero".to_string()))
}

fn prepare_dirs(settings: &Settings) -> Result<()> {
    for dir in [&settings.data_dir, &settings.raw_dir, &settings.cache_dir] {
        fs::create_dir_all(dir)?;
    }
    Ok(())
}

fn http_client(settings: &Settings) -> Result<HttpClient> {
    HttpClient::new(settings.user_agent.clone(), settings.cache_dir.clone()).map_err(Into::into)
}

async fn http_client_async(user_agent: String, cache_dir: PathBuf) -> Result<HttpClient> {
    Ok(tokio::task::spawn_blocking(move || HttpClient::new(user_agent, cache_dir)).await??)
}

fn ai_config(
    settings: &Settings,
    model: Option<String>,
    max_completion_tokens: Option<u64>,
    temperature: Option<f64>,
    top_p: Option<f64>,
) -> AiConfig {
    let mut config = AiConfig::from_settings(settings);
    if let Some(model) = model {
        config.model = model;
    }
    if let Some(max_completion_tokens) = max_completion_tokens {
        config.max_completion_tokens = max_completion_tokens;
    }
    if let Some(temperature) = temperature {
        config.temperature = temperature;
    }
    if let Some(top_p) = top_p {
        config.top_p = top_p;
    }
    config
}

fn game_mode_value(mode: GameMode) -> Option<String> {
    match mode {
        GameMode::All => None,
        GameMode::Standard => Some("standard".to_string()),
        GameMode::Brawl => Some("brawl".to_string()),
    }
}

fn usize_to_i64(value: usize) -> i64 {
    i64::try_from(value).unwrap_or(i64::MAX)
}

fn bounded_limit(value: usize) -> i64 {
    usize_to_i64(value).clamp(1, 500)
}

fn print_json<T: Serialize + ?Sized>(value: &T) -> Result<()> {
    println!("{}", serde_json::to_string_pretty(value)?);
    Ok(())
}

async fn print_status(pool: &PgPool, settings: &Settings) -> Result<()> {
    let status = dbrain_retrieval::status(pool).await?;
    println!("Project: {}", settings.project_root.display());
    println!("Raw:     {}", settings.raw_dir.display());
    println!("Cache:   {}", settings.cache_dir.display());
    println!();
    println!("Source documents:");
    print_status_rows(get(&status, "source_documents"), |row| {
        format!(
            "  {}: {}",
            display_value(get(row, "source")),
            display_value(get(row, "documents"))
        )
    });
    println!();
    println!("Entity snapshots:");
    print_status_rows(get(&status, "entity_snapshots"), |row| {
        format!(
            "  {} / {}: {}",
            display_value(get(row, "source")),
            display_value(get(row, "entity_type")),
            display_value(get(row, "snapshots"))
        )
    });
    println!();
    println!("Patch events:");
    print_status_rows(get(&status, "patch_events"), |row| {
        format!(
            "  {} / {}: {}",
            display_value(get(row, "source_kind")),
            display_value(get(row, "entity_type")),
            display_value(get(row, "events"))
        )
    });
    println!();
    println!("Entities:");
    print_status_rows(get(&status, "entities"), |row| {
        format!(
            "  {}: {}",
            display_value(get(row, "entity_type")),
            display_value(get(row, "entities"))
        )
    });
    println!();
    println!("Derived data:");
    print_status_rows(get(&status, "derived_data"), |row| {
        format!(
            "  {}: {}",
            display_value(get(row, "table")),
            display_value(get(row, "count"))
        )
    });
    Ok(())
}

fn print_status_rows<F>(rows: Option<&Value>, render: F)
where
    F: Fn(&Value) -> String,
{
    let Some(rows) = rows.and_then(Value::as_array) else {
        println!("  none");
        return;
    };
    if rows.is_empty() {
        println!("  none");
        return;
    }
    for row in rows {
        println!("{}", render(row));
    }
}

async fn load_lineage(pool: &PgPool, query: Option<&str>, limit: usize) -> Result<Vec<Value>> {
    let max_rows = bounded_limit(limit);
    let rows = if let Some(query) = query.filter(|value| !value.trim().is_empty()) {
        let norm = dbrain_normalize::normalize_alias(query);
        sqlx::query_scalar::<_, Value>(
            r#"
            SELECT to_jsonb(t) FROM (
                SELECT *
                FROM brain.entity_lineage
                WHERE source_name_norm = $1
                   OR target_name_norm = $1
                   OR owner_name_norm = $1
                ORDER BY confidence DESC, id ASC
                LIMIT $2
            ) AS t
            "#,
        )
        .bind(norm)
        .bind(max_rows)
        .fetch_all(pool)
        .await?
    } else {
        sqlx::query_scalar::<_, Value>(
            r#"
            SELECT to_jsonb(t) FROM (
                SELECT *
                FROM brain.entity_lineage
                ORDER BY patch_event_id DESC, id DESC
                LIMIT $1
            ) AS t
            "#,
        )
        .bind(max_rows)
        .fetch_all(pool)
        .await?
    };
    Ok(rows)
}

async fn load_legacy(pool: &PgPool, query: Option<&str>, limit: usize) -> Result<Vec<Value>> {
    let max_rows = bounded_limit(limit);
    let rows = if let Some(query) = query.filter(|value| !value.trim().is_empty()) {
        sqlx::query_scalar::<_, Value>(
            r#"
            SELECT to_jsonb(t) FROM (
                SELECT *
                FROM brain.legacy_entities
                WHERE canonical_name ILIKE $1 OR name_norm LIKE $2
                ORDER BY confidence DESC, event_count DESC, canonical_name
                LIMIT $3
            ) AS t
            "#,
        )
        .bind(format!("%{query}%"))
        .bind(format!("%{}%", query.to_lowercase()))
        .bind(max_rows)
        .fetch_all(pool)
        .await?
    } else {
        sqlx::query_scalar::<_, Value>(
            r#"
            SELECT to_jsonb(t) FROM (
                SELECT *
                FROM brain.legacy_entities
                ORDER BY confidence DESC, event_count DESC, canonical_name
                LIMIT $1
            ) AS t
            "#,
        )
        .bind(max_rows)
        .fetch_all(pool)
        .await?
    };
    Ok(rows)
}

fn print_context(ctx: &Value) {
    if let Some(best_match) = get(ctx, "best_match").filter(|value| !value.is_null()) {
        println!(
            "Best match: {} / {} ({})",
            display_value(get(best_match, "entity_type")),
            display_value(get(best_match, "canonical_name")),
            display_value(get(best_match, "primary_external_id"))
        );
    } else {
        println!("Best match: none");
    }
    println!("Aliases: {}", array_len(get(ctx, "aliases")));
    let sheet = get(ctx, "sheet_stats").unwrap_or(&Value::Null);
    println!(
        "Sheet stats: {}",
        if bool_value(get(sheet, "available")) {
            "yes"
        } else {
            "no"
        }
    );
    let enrichments = get(ctx, "enrichments").unwrap_or(&Value::Null);
    println!(
        "Enrichments: {} / {} rows",
        if bool_value(get(enrichments, "available")) {
            "yes"
        } else {
            "no"
        },
        array_len(get(enrichments, "rows"))
    );
    println!("Patch events: {}", array_len(get(ctx, "patch_events")));
    if let Some(events) = get(ctx, "patch_events").and_then(Value::as_array) {
        for event in events.iter().take(10) {
            let date = str_value(get(event, "posted_at")).unwrap_or("unknown-date");
            let section = str_value(get(event, "section")).unwrap_or("Unsectioned");
            let entity = str_value(get(event, "entity_name"))
                .or_else(|| str_value(get(event, "entity_type")))
                .unwrap_or_default();
            println!(
                "- {} [{}] {} / {} / {}",
                date,
                display_value(get(event, "source_kind")),
                section,
                entity,
                display_value(get(event, "change_type"))
            );
            println!("  {}", display_value(get(event, "normalized_line")));
        }
    }
}

fn print_timeline(timeline: &Value) {
    if let Some(best_match) = get(timeline, "best_match").filter(|value| !value.is_null()) {
        println!(
            "Timeline: {} / {} ({})",
            display_value(get(best_match, "entity_type")),
            display_value(get(best_match, "canonical_name")),
            display_value(get(best_match, "primary_external_id"))
        );
    } else {
        println!(
            "Timeline: {} (fallback)",
            display_value(get(timeline, "query"))
        );
    }
    println!(
        "Patches: {} / Events: {}",
        display_value(get(timeline, "patch_count")),
        display_value(get(timeline, "event_count"))
    );
    if let Some(by_kind) = get(timeline, "impact_summary")
        .and_then(|impact| get(impact, "by_kind"))
        .and_then(Value::as_object)
    {
        if !by_kind.is_empty() {
            let parts = by_kind
                .iter()
                .map(|(key, value)| format!("{key}={}", display_value(Some(value))))
                .collect::<Vec<_>>();
            println!("Impact kinds: {}", parts.join(", "));
        }
    }
    if let Some(patches) = get(timeline, "patches").and_then(Value::as_array) {
        for patch in patches.iter().take(12) {
            let date = str_value(get(patch, "date")).unwrap_or("unknown-date");
            println!(
                "- {} [{}] {}",
                date,
                display_value(get(patch, "source")),
                display_value(get(patch, "title"))
            );
            if let Some(events) = get(patch, "events").and_then(Value::as_array) {
                for event in events.iter().take(8) {
                    let kind = str_value(get(event, "impact_kind")).unwrap_or("unknown");
                    let level = str_value(get(event, "impact_level")).unwrap_or("unknown");
                    let line = str_value(get(event, "normalized_line"))
                        .or_else(|| str_value(get(event, "raw_line")))
                        .unwrap_or_default();
                    println!("  - {kind}/{level}: {line}");
                }
            }
        }
    }
}

fn print_review_context(review_context: &Value) {
    let summary = get(review_context, "entity_summary").unwrap_or(&Value::Null);
    let name = str_value(get(summary, "name"))
        .or_else(|| str_value(get(review_context, "query")))
        .unwrap_or_default();
    let entity_type = str_value(get(summary, "entity_type")).unwrap_or("unknown");
    println!("Review context: {entity_type} / {name}");
    println!(
        "Matched: {}",
        if bool_value(get(summary, "matched")) {
            "yes"
        } else {
            "no"
        }
    );
    let timeline = get(review_context, "timeline_signals").unwrap_or(&Value::Null);
    println!("Events: {}", display_or(get(timeline, "event_count"), "0"));
    let latest = get(timeline, "latest_patch").unwrap_or(&Value::Null);
    if latest
        .as_object()
        .map(|object| !object.is_empty())
        .unwrap_or(false)
    {
        println!(
            "Latest patch: {} / {}",
            str_value(get(latest, "posted_at")).unwrap_or("unknown-date"),
            display_value(get(latest, "patch_title"))
        );
    }
    let stats = get(review_context, "current_stat_hints").unwrap_or(&Value::Null);
    println!(
        "Sheet stats: {} / {} hints",
        if bool_value(get(stats, "available")) {
            "yes"
        } else {
            "no"
        },
        array_len(get(stats, "hints"))
    );
    if let Some(questions) = get(review_context, "open_questions").and_then(Value::as_array) {
        if !questions.is_empty() {
            println!("Open questions:");
            for question in questions.iter().take(10) {
                println!("- {}", display_value(Some(question)));
            }
        }
    }
}

fn print_quality_report(report: &Value) {
    let summary = get(report, "summary").unwrap_or(&Value::Null);
    println!(
        "Quality: {}",
        if bool_value(get(report, "ok")) {
            "ok"
        } else {
            "needs attention"
        }
    );
    println!(
        "Checks: {} / warnings={} / errors={}",
        display_or(get(summary, "checks"), "0"),
        display_or(get(summary, "warnings"), "0"),
        display_or(get(summary, "errors"), "0")
    );
    if let Some(checks) = get(report, "checks").and_then(Value::as_array) {
        for check in checks {
            if str_value(get(check, "severity")) == Some("ok") {
                continue;
            }
            println!(
                "- {} {}: {}",
                display_value(get(check, "severity")),
                display_value(get(check, "check")),
                display_or(get(check, "rows"), "0")
            );
            println!("  {}", display_value(get(check, "message")));
            if let Some(samples) = get(check, "samples").and_then(Value::as_array) {
                for sample in samples.iter().take(3) {
                    println!("  sample: {}", display_value(Some(sample)));
                }
            }
        }
    }
}

fn print_lineage(rows: &[Value], query: Option<&str>) {
    let label = query.unwrap_or("latest");
    println!("Lineage: {label} / rows={}", rows.len());
    for row in rows {
        let relation = display_value(get(row, "relation_type"));
        let source = display_value(get(row, "source_name"));
        let target = str_value(get(row, "target_name"));
        let owner = str_value(get(row, "owner_name"));
        let metadata = get(row, "metadata").unwrap_or(&Value::Null);
        let owner_text = owner
            .map(|value| format!(" / owner={value}"))
            .unwrap_or_default();
        let target_text = target
            .map(|value| format!(" -> {value}"))
            .unwrap_or_default();
        println!("- {relation}: {source}{target_text}{owner_text}");
        println!(
            "  {} / {}",
            str_value(get(metadata, "posted_at")).unwrap_or("unknown-date"),
            display_value(get(metadata, "patch_title"))
        );
        if let Some(line) = str_value(get(metadata, "line")).filter(|value| !value.is_empty()) {
            println!("  {line}");
        }
    }
}

fn print_legacy(rows: &[Value], query: Option<&str>) {
    let label = query.unwrap_or("top");
    println!("Legacy entities: {label} / rows={}", rows.len());
    for row in rows {
        println!(
            "- {}: {} events={} confidence={} status={}",
            display_value(get(row, "legacy_type")),
            display_value(get(row, "canonical_name")),
            display_value(get(row, "event_count")),
            display_value(get(row, "confidence")),
            display_value(get(row, "status"))
        );
        if let Some(sample) = get(row, "samples")
            .and_then(Value::as_array)
            .and_then(|samples| samples.first())
        {
            println!(
                "  {} / {}",
                str_value(get(sample, "posted_at")).unwrap_or("unknown-date"),
                display_value(get(sample, "patch_title"))
            );
            println!("  {}", display_value(get(sample, "line")));
        }
    }
}

fn print_build_context(ctx: &Value) {
    let hero = get(ctx, "hero").unwrap_or(&Value::Null);
    let economy = get(ctx, "economy").unwrap_or(&Value::Null);
    let build = get(ctx, "build").unwrap_or(&Value::Null);
    println!(
        "Build: {} / {}",
        display_value(get(hero, "name")),
        display_value(get(hero, "hero_type"))
    );
    if let Some(role) = str_value(get(hero, "role")).filter(|value| !value.is_empty()) {
        println!("Role: {role}");
    }
    if let Some(playstyle) = str_value(get(hero, "playstyle")).filter(|value| !value.is_empty()) {
        println!("Playstyle: {playstyle}");
    }
    let gameplan = get(hero, "inferred_gameplan").unwrap_or(&Value::Null);
    if gameplan
        .as_object()
        .map(|object| !object.is_empty())
        .unwrap_or(false)
    {
        println!(
            "Understood gameplan: {}",
            display_value(get(gameplan, "summary"))
        );
        let needs = join_array(get(gameplan, "needs"), usize::MAX);
        if !needs.is_empty() {
            println!("Needs: {needs}");
        }
        let damage_profile = get(gameplan, "damage_profile").unwrap_or(&Value::Null);
        if damage_profile
            .as_object()
            .map(|object| !object.is_empty())
            .unwrap_or(false)
        {
            println!(
                "Damage profile: {} (ability_damage={}, spirit_scaling={}, weapon_hooks={})",
                display_value(get(damage_profile, "damage_plan")),
                display_value(get(damage_profile, "ability_damage_sources")),
                display_value(get(damage_profile, "spirit_scaling_damage_sources")),
                display_value(get(damage_profile, "weapon_stat_sources"))
            );
        }
        let priority_stats = join_array(get(gameplan, "priority_scaling_stats"), usize::MAX);
        if !priority_stats.is_empty() {
            println!("Priority scaling: {priority_stats}");
        }
        if let Some(abilities) = get(hero, "abilities").and_then(Value::as_array) {
            if !abilities.is_empty() {
                println!("Abilities:");
                for ability in abilities {
                    let tags = join_array(get(ability, "role_tags"), usize::MAX);
                    let key_props = get(ability, "key_properties")
                        .and_then(Value::as_array)
                        .map(|properties| {
                            properties
                                .iter()
                                .take(4)
                                .map(|prop| {
                                    format!(
                                        "{}: {}",
                                        display_value(get(prop, "label")),
                                        format_prop_value(prop)
                                    )
                                })
                                .collect::<Vec<_>>()
                        })
                        .unwrap_or_default();
                    println!("- {}: {}", display_value(get(ability, "name")), tags);
                    if !key_props.is_empty() {
                        println!("  {}", key_props.join("; "));
                    }
                }
            }
        }
        if let Some(lane_priorities) = get(gameplan, "lane_priorities").and_then(Value::as_array) {
            if !lane_priorities.is_empty() {
                println!("Lane priorities:");
                for priority in lane_priorities {
                    println!("- {}", display_value(Some(priority)));
                }
            }
        }
    }
    println!(
        "Shop spike: {} souls per category",
        display_value(get(economy, "important_shop_spike"))
    );
    let wiki_rules = get(economy, "wiki_rules").unwrap_or(&Value::Null);
    if wiki_rules
        .as_object()
        .map(|object| !object.is_empty())
        .unwrap_or(false)
    {
        let tiers = join_array(get(wiki_rules, "item_tiers"), usize::MAX);
        println!(
            "Shop rules: tiers={}; active limit={}; bonus cap={}",
            tiers,
            display_value(get(wiki_rules, "active_item_limit")),
            display_value(get(wiki_rules, "shop_bonus_cap"))
        );
    }
    println!("Plan: {}", display_value(get(build, "plan")));
    if let Some(lane_model) = get(build, "lane_decision_model").and_then(Value::as_array) {
        if !lane_model.is_empty() {
            println!("Lane decision model:");
            for line in lane_model {
                println!("- {}", display_value(Some(line)));
            }
        }
    }
    if let Some(signals) = get(ctx, "statlocker_signals").and_then(Value::as_array) {
        if !signals.is_empty() {
            println!("Statlocker WPA signals:");
            for signal in signals.iter().take(8) {
                let wpa = get(signal, "cost_relative_wpa")
                    .filter(|value| !value.is_null())
                    .or_else(|| get(signal, "wpa"));
                println!(
                    "- {}: wpa={} n={} time={}",
                    display_value(get(signal, "item")),
                    display_value(wpa),
                    display_value(get(signal, "sample_size")),
                    display_value(get(signal, "mean_purchase_time_min"))
                );
            }
        }
    }
    println!();
    for section in ["early", "core", "late", "situational"] {
        let Some(rows) = get(build, section).and_then(Value::as_array) else {
            continue;
        };
        if rows.is_empty() {
            continue;
        }
        println!("{}:", capitalize(section));
        for row in rows {
            println!(
                "- {} [{} T{} / {}] score={}",
                display_value(get(row, "name")),
                display_value(get(row, "slot")),
                display_value(get(row, "tier")),
                display_value(get(row, "cost")),
                display_value(get(row, "score"))
            );
            let archetypes = join_array(get(row, "archetypes"), usize::MAX);
            if !archetypes.is_empty() {
                println!("  archetypes: {archetypes}");
            }
            let why = join_array(get(row, "why"), usize::MAX).replace(", ", "; ");
            if !why.is_empty() {
                println!("  why: {why}");
            }
            let warnings = join_array(get(row, "warnings"), usize::MAX).replace(", ", "; ");
            if !warnings.is_empty() {
                println!("  warn: {warnings}");
            }
        }
        println!();
    }
    let targets = get(build, "shop_routes_to_4800").and_then(Value::as_object);
    if let Some(targets) = targets.filter(|value| !value.is_empty()) {
        println!("Shop routes to 4800:");
        for (slot, target) in targets {
            let route_names = get(target, "items")
                .and_then(Value::as_array)
                .map(|items| {
                    items
                        .iter()
                        .take(5)
                        .map(|row| display_value(get(row, "name")))
                        .collect::<Vec<_>>()
                        .join(", ")
                })
                .unwrap_or_default();
            println!(
                "- {}: spend={} / reached={} / {}",
                str_value(get(target, "label")).unwrap_or(slot),
                display_value(get(target, "spend")),
                if bool_value(get(target, "target_reached")) {
                    "yes"
                } else {
                    "no"
                },
                route_names
            );
        }
    }
    if let Some(rejected) = get(ctx, "rejected_expensive_items").and_then(Value::as_array) {
        if !rejected.is_empty() {
            println!();
            println!("Expensive items to justify:");
            for row in rejected.iter().take(6) {
                let warnings = join_array(get(row, "warnings"), usize::MAX).replace(", ", "; ");
                println!(
                    "- {} cost={} score={} bucket={} {}",
                    display_value(get(row, "name")),
                    display_value(get(row, "cost")),
                    display_value(get(row, "score")),
                    display_value(get(row, "bucket")),
                    warnings
                );
            }
        }
    }
}

fn print_item_context(ctx: &Value) {
    println!(
        "Item: {} [{} T{} / {}]",
        display_value(get(ctx, "name")),
        display_value(get(ctx, "slot")),
        display_value(get(ctx, "tier")),
        display_value(get(ctx, "cost"))
    );
    println!(
        "Active: {} / activation={}",
        if bool_value(get(ctx, "is_active")) {
            "yes"
        } else {
            "no"
        },
        display_value(get(ctx, "activation"))
    );
    let archetypes = join_array(get(ctx, "archetypes"), usize::MAX);
    if !archetypes.is_empty() {
        println!("Archetypes: {archetypes}");
    }
    if let Some(description) = str_value(get(ctx, "description")).filter(|value| !value.is_empty())
    {
        println!("Desc: {description}");
    }
    if let Some(properties) = get(ctx, "properties").and_then(Value::as_array) {
        if !properties.is_empty() {
            println!("Properties:");
            for prop in properties.iter().take(20) {
                println!(
                    "- {}: {}",
                    display_value(get(prop, "label")),
                    format_prop_value(prop)
                );
                let scales = join_array(get(prop, "scales_with"), usize::MAX);
                if !scales.is_empty() {
                    println!("  scales: {scales}");
                }
            }
        }
    }
}

fn print_analysis_result(target: &str, result: &Value) {
    match target {
        "save-review" => {
            println!(
                "Analysis note: {} / {} / {}",
                display_value(get(result, "id")),
                display_value(get(result, "query")),
                display_value(get(result, "status"))
            );
            println!(
                "Entity: {} / {}",
                display_value(get(result, "entity_type")),
                display_value(get(result, "entity_name"))
            );
            println!(
                "Context hash: {}",
                display_value(get(result, "context_hash"))
            );
        }
        "run-fireworks" | "run-minimax" | "run-ai" => {
            if bool_value(get(result, "dry_run")) {
                let messages = get(result, "request")
                    .and_then(|request| get(request, "messages"))
                    .and_then(Value::as_array)
                    .map(Vec::len)
                    .unwrap_or(0);
                println!("KI-Probelauf: {}", display_value(get(result, "model")));
                println!(
                    "Lokaler Connector: {}",
                    display_value(get(result, "endpoint"))
                );
                println!(
                    "Abo-Connector eingerichtet: {}",
                    if bool_value(get(result, "subscription_configured")) {
                        "yes"
                    } else {
                        "no"
                    }
                );
                println!("Messages: {messages}");
                return;
            }
            let note = get(result, "note").unwrap_or(&Value::Null);
            println!(
                "KI-Analyse: note={} model={}",
                display_value(get(note, "id")),
                display_value(get(result, "model"))
            );
            println!("{}", display_value(get(result, "result_text")));
        }
        _ => {
            let rows = result.as_array().map(Vec::as_slice).unwrap_or(&[]);
            println!("Analysis notes: rows={}", rows.len());
            for row in rows {
                println!(
                    "- {}: {} / {} / {} / {}",
                    display_value(get(row, "id")),
                    display_value(get(row, "query")),
                    display_value(get(row, "entity_type")),
                    display_value(get(row, "entity_name")),
                    display_value(get(row, "status"))
                );
                println!(
                    "  {} / {} / {}",
                    display_value(get(row, "prompt_version")),
                    str_value(get(row, "model")).unwrap_or("no-model"),
                    display_value(get(row, "context_hash"))
                );
            }
        }
    }
}

fn print_learn_result(target: &str, result: &Value) {
    match target {
        "import-steam-builds" => {
            println!(
                "Steam build import: {}",
                display_value(get(result, "source"))
            );
            println!(
                "rows={} imported={} updated={} skipped={}",
                display_or(get(result, "rows_seen"), "0"),
                display_or(get(result, "imported"), "0"),
                display_or(get(result, "updated"), "0"),
                display_or(get(result, "skipped"), "0")
            );
            if get(result, "error").is_some_and(|value| !value.is_null()) {
                println!("error={}", display_value(get(result, "error")));
            }
        }
        "list-builds" => {
            let rows = result.as_array().map(Vec::as_slice).unwrap_or(&[]);
            println!("Learned builds: rows={}", rows.len());
            for row in rows {
                let items = join_array(get(row, "item_names"), 8);
                println!(
                    "- {}: {} rank={} quality={} score={} / {}",
                    display_value(get(row, "id")),
                    display_value(get(row, "hero_name")),
                    display_value(get(row, "source_rank")),
                    display_value(get(row, "quality_tier")),
                    display_value(get(row, "quality_score")),
                    display_value(get(row, "name"))
                );
                if !items.is_empty() {
                    println!("  items: {items}");
                }
            }
        }
        "analyze-build" => {
            if bool_value(get(result, "dry_run")) {
                let messages = request_message_count(result);
                println!(
                    "Build learning dry-run: build={} model={}",
                    display_value(get(result, "build_id")),
                    display_value(get(result, "model"))
                );
                println!(
                    "Lokaler Connector: {}",
                    display_value(get(result, "endpoint"))
                );
                println!(
                    "Abo-Connector eingerichtet: {}",
                    if bool_value(get(result, "subscription_configured")) {
                        "yes"
                    } else {
                        "no"
                    }
                );
                println!("Messages: {messages}");
                let note = get(result, "note").unwrap_or(&Value::Null);
                if note
                    .as_object()
                    .map(|object| !object.is_empty())
                    .unwrap_or(false)
                {
                    println!(
                        "Stored context note: {} / {}",
                        display_value(get(note, "id")),
                        display_value(get(note, "status"))
                    );
                }
                return;
            }
            println!(
                "Build learning analysis: build={} model={}",
                display_value(get(result, "build_id")),
                display_value(get(result, "model"))
            );
            println!("{}", display_value(get(result, "result_text")));
        }
        "analyze-next" => {
            println!(
                "Build learning batch: selected={} model={}",
                display_or(get(result, "pending_selected"), "0"),
                display_value(get(result, "model"))
            );
            println!(
                "Dry run: {}",
                if bool_value(get(result, "dry_run")) {
                    "yes"
                } else {
                    "no"
                }
            );
            println!(
                "Abo-Connector eingerichtet: {}",
                if bool_value(get(result, "subscription_configured")) {
                    "yes"
                } else {
                    "no"
                }
            );
            if let Some(rows) = get(result, "results").and_then(Value::as_array) {
                for row in rows {
                    println!(
                        "- {}: {} rank={} {} note={} / {}",
                        display_value(get(row, "build_id")),
                        display_value(get(row, "hero_name")),
                        display_value(get(row, "source_rank")),
                        display_value(get(row, "status")),
                        str_value(get(row, "note_id")).unwrap_or("-"),
                        display_value(get(row, "name"))
                    );
                    if let Some(error) =
                        str_value(get(row, "error")).filter(|value| !value.is_empty())
                    {
                        println!("  error: {error}");
                    }
                }
            }
        }
        _ => {}
    }
}

fn print_player_result(target: &str, result: &Value) {
    match target {
        "list-matches" => {
            let rows = result.as_array().map(Vec::as_slice).unwrap_or(&[]);
            println!("Player matches: rows={}", rows.len());
            for row in rows {
                let summary = get(row, "summary").unwrap_or(&Value::Null);
                let hero_id = get(row, "hero_id")
                    .filter(|value| !value.is_null())
                    .or_else(|| get(summary, "heroId"))
                    .or_else(|| get(summary, "hero_id"));
                let won = get(summary, "won").and_then(Value::as_bool);
                let result_text = match won {
                    Some(true) => "win",
                    Some(false) => "loss",
                    None => "unknown",
                };
                println!(
                    "- account={} match={} hero_id={} result={}",
                    display_value(get(row, "account_id")),
                    display_value(get(row, "match_id")),
                    display_or(hero_id, "-"),
                    result_text
                );
            }
        }
        "match-context" => {
            println!(
                "Player match context: account={} match={}",
                display_value(get(result, "account_id")),
                display_value(get(result, "match_id"))
            );
            println!(
                "Hero: {} ({})",
                display_or(get(result, "hero_name"), "-"),
                display_or(get(result, "hero_id"), "-")
            );
            let player_match = get(result, "player_match").and_then(Value::as_object);
            let keys = player_match
                .map(|object| object.keys().cloned().collect::<Vec<_>>().join(", "))
                .unwrap_or_else(|| "-".to_string());
            println!("Match row keys: {keys}");
            let detail = get(result, "match_detail").and_then(Value::as_object);
            println!(
                "Match detail: {}",
                if detail.is_some_and(|object| !object.is_empty()) {
                    "yes"
                } else {
                    "no"
                }
            );
            let api_match = get(result, "deadlock_api_match").unwrap_or(&Value::Null);
            let actual_items = get(api_match, "player")
                .and_then(|player| get(player, "actual_item_timeline"))
                .and_then(Value::as_array)
                .map(Vec::len)
                .unwrap_or(0);
            println!(
                "Deadlock API match: {}",
                if api_match
                    .as_object()
                    .map(|object| !object.is_empty())
                    .unwrap_or(false)
                {
                    "yes"
                } else {
                    "no"
                }
            );
            if actual_items > 0 {
                println!("Actual item events: {actual_items}");
            }
            let build_analysis = get(result, "player_build_analysis").and_then(Value::as_object);
            println!(
                "Player build analysis: {}",
                if build_analysis.is_some_and(|object| !object.is_empty()) {
                    "yes"
                } else {
                    "no"
                }
            );
        }
        "analyze-match" => {
            if bool_value(get(result, "dry_run")) {
                println!(
                    "Player match dry-run: account={} match={} model={}",
                    display_value(get(result, "account_id")),
                    display_value(get(result, "match_id")),
                    display_value(get(result, "model"))
                );
                println!(
                    "Hero: {} ({})",
                    display_or(get(result, "hero_name"), "-"),
                    display_or(get(result, "hero_id"), "-")
                );
                println!(
                    "Lokaler Connector: {}",
                    display_value(get(result, "endpoint"))
                );
                println!(
                    "Abo-Connector eingerichtet: {}",
                    if bool_value(get(result, "subscription_configured")) {
                        "yes"
                    } else {
                        "no"
                    }
                );
                println!("Messages: {}", request_message_count(result));
                let note = get(result, "note").unwrap_or(&Value::Null);
                if note
                    .as_object()
                    .map(|object| !object.is_empty())
                    .unwrap_or(false)
                {
                    println!(
                        "Stored context note: {} / {}",
                        display_value(get(note, "id")),
                        display_value(get(note, "status"))
                    );
                }
                return;
            }
            println!(
                "Player match analysis: account={} match={} model={}",
                display_value(get(result, "account_id")),
                display_value(get(result, "match_id")),
                display_value(get(result, "model"))
            );
            println!(
                "Hero: {} ({})",
                display_or(get(result, "hero_name"), "-"),
                display_or(get(result, "hero_id"), "-")
            );
            println!("{}", display_value(get(result, "result_text")));
        }
        "analyze-next" => {
            println!(
                "Player match batch: selected={} model={}",
                display_or(get(result, "pending_selected"), "0"),
                display_value(get(result, "model"))
            );
            println!(
                "Dry run: {}",
                if bool_value(get(result, "dry_run")) {
                    "yes"
                } else {
                    "no"
                }
            );
            println!(
                "Abo-Connector eingerichtet: {}",
                if bool_value(get(result, "subscription_configured")) {
                    "yes"
                } else {
                    "no"
                }
            );
            if let Some(rows) = get(result, "results").and_then(Value::as_array) {
                for row in rows {
                    let hero = get(row, "hero_name")
                        .filter(|value| !value.is_null())
                        .or_else(|| get(row, "hero_id"));
                    println!(
                        "- account={} match={} hero={} {} note={}",
                        display_value(get(row, "account_id")),
                        display_value(get(row, "match_id")),
                        display_or(hero, "-"),
                        display_value(get(row, "status")),
                        display_or(get(row, "note_id"), "-")
                    );
                    if let Some(error) =
                        str_value(get(row, "error")).filter(|value| !value.is_empty())
                    {
                        println!("  error: {error}");
                    }
                }
            }
        }
        _ => {}
    }
}

fn request_message_count(result: &Value) -> usize {
    get(result, "request")
        .and_then(|request| get(request, "messages"))
        .and_then(Value::as_array)
        .map(Vec::len)
        .unwrap_or(0)
}

fn format_prop_value(prop: &Value) -> String {
    let prefix = str_value(get(prop, "prefix")).unwrap_or_default();
    let value = get(prop, "value")
        .filter(|value| !value.is_null())
        .map(|value| display_value(Some(value)))
        .unwrap_or_default();
    let mut postfix = str_value(get(prop, "postfix"))
        .unwrap_or_default()
        .to_string();
    if !postfix.is_empty() && value.ends_with(postfix.trim()) {
        postfix.clear();
    }
    render_sign_token(prefix, &value, &postfix)
}

fn render_sign_token(prefix: &str, value: &str, postfix: &str) -> String {
    let mut rendered_prefix = prefix.to_string();
    let mut rendered_postfix = postfix.to_string();
    if !rendered_prefix.contains("{s:sign}") && !rendered_postfix.contains("{s:sign}") {
        return format!("{rendered_prefix}{value}{rendered_postfix}");
    }
    let sign = if value.trim_start().starts_with('-') {
        "-"
    } else {
        "+"
    };
    let unsigned_value = value.trim_start_matches(['+', '-']);
    rendered_prefix = rendered_prefix.replace("{s:sign}", sign);
    rendered_postfix = rendered_postfix.replace("{s:sign}", sign);
    format!("{rendered_prefix}{unsigned_value}{rendered_postfix}")
}

fn get<'a>(value: &'a Value, key: &str) -> Option<&'a Value> {
    value.as_object().and_then(|object| object.get(key))
}

fn str_value(value: Option<&Value>) -> Option<&str> {
    value.and_then(Value::as_str)
}

fn bool_value(value: Option<&Value>) -> bool {
    value.and_then(Value::as_bool).unwrap_or(false)
}

fn array_len(value: Option<&Value>) -> usize {
    value.and_then(Value::as_array).map(Vec::len).unwrap_or(0)
}

fn display_or(value: Option<&Value>, fallback: &str) -> String {
    let rendered = display_value(value);
    if rendered.is_empty() || rendered == "null" {
        fallback.to_string()
    } else {
        rendered
    }
}

fn display_value(value: Option<&Value>) -> String {
    match value {
        Some(Value::String(value)) => value.clone(),
        Some(Value::Null) | None => String::new(),
        Some(other) => other.to_string(),
    }
}

fn join_array(value: Option<&Value>, limit: usize) -> String {
    value
        .and_then(Value::as_array)
        .map(|items| {
            items
                .iter()
                .take(limit)
                .map(|item| display_value(Some(item)))
                .collect::<Vec<_>>()
                .join(", ")
        })
        .unwrap_or_default()
}

fn capitalize(value: &str) -> String {
    let mut chars = value.chars();
    match chars.next() {
        Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
        None => String::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::CommandFactory;

    #[test]
    fn wissensabfragen_erzwingen_read_only() {
        for argv in [
            vec!["deadlock-brain", "ask-context", "Warden"],
            vec!["deadlock-brain", "context", "Warden"],
            vec!["deadlock-brain", "timeline", "Warden"],
            vec!["deadlock-brain", "review", "Warden"],
            vec!["deadlock-brain", "lineage"],
            vec!["deadlock-brain", "legacy"],
            vec!["deadlock-brain", "entities", "--query", "Warden"],
            vec![
                "deadlock-brain",
                "reason",
                "build",
                "Warden",
                "--no-persist",
            ],
            vec![
                "deadlock-brain",
                "reason",
                "patch-impact",
                "Warden",
                "--no-persist",
            ],
            vec![
                "deadlock-brain",
                "reason",
                "backtest",
                "--hero",
                "Warden",
                "--no-persist",
            ],
        ] {
            let cli = Cli::try_parse_from(argv).expect("read-only command must parse");
            assert!(command_is_read_only(&cli.command));
        }
    }

    #[test]
    fn schreibende_befehle_bleiben_schreibfaehig() {
        for argv in [
            vec!["deadlock-brain", "reason", "build", "Warden"],
            vec!["deadlock-brain", "reason", "patch-impact", "Warden"],
            vec!["deadlock-brain", "reason", "backtest", "--hero", "Warden"],
        ] {
            let cli = Cli::try_parse_from(argv).expect("write-capable command must parse");
            assert!(!command_is_read_only(&cli.command));
        }
    }

    fn assert_no_persist_cli(command: &str, hero: &[&str]) {
        let mut argv = vec!["deadlock-brain", "reason", command];
        argv.extend_from_slice(hero);
        for no_persist in [false, true] {
            if no_persist {
                argv.push("--no-persist");
            }
            let cli = Cli::try_parse_from(&argv).unwrap();
            let Commands::Reason { target } = cli.command else {
                panic!("Reason-Befehl erwartet");
            };
            let actual = match target {
                ReasonCommands::Build(args) => args.no_persist,
                ReasonCommands::PatchImpact(args) => args.no_persist,
                ReasonCommands::Backtest(args) => args.no_persist,
            };
            assert_eq!(actual, no_persist);
        }
        let help =
            Cli::try_parse_from(["deadlock-brain", "reason", command, "--help"]).unwrap_err();
        assert_eq!(help.kind(), clap::error::ErrorKind::DisplayHelp);
        assert!(help.to_string().contains("--no-persist"));
    }

    #[test]
    fn fix2_build_no_persist_cli() {
        assert_no_persist_cli("build", &["Warden"]);
    }

    #[test]
    fn fix2_patch_impact_no_persist_cli() {
        assert_no_persist_cli("patch-impact", &["Warden"]);
    }

    #[test]
    fn fix2_backtest_no_persist_cli() {
        assert_no_persist_cli("backtest", &["--hero", "Warden"]);
    }

    #[test]
    fn fix2_no_persist_conflicts_with_publish() {
        let error = Cli::try_parse_from([
            "deadlock-brain",
            "reason",
            "build",
            "Warden",
            "--no-persist",
            "--publish",
        ])
        .unwrap_err();
        assert_eq!(error.kind(), clap::error::ErrorKind::ArgumentConflict);
    }
    #[test]
    fn analysis_run_ai_accepts_public_command_names() {
        for command_name in ["run-fireworks", "run-minimax", "run-ai"] {
            let cli =
                Cli::try_parse_from(["deadlock-brain", "analysis", command_name, "Lady Geist"])
                    .expect("parse analysis run command");

            let Commands::Analysis {
                target: AnalysisCommands::RunAi(args),
            } = cli.command
            else {
                panic!("expected analysis run ai for {command_name}");
            };
            assert_eq!(args.query, "Lady Geist");
        }
    }

    #[test]
    fn cli_json_preserves_current_wire_statuses() {
        for (status, expected) in [
            (brain_client::AnswerStatus::BuildRejected, "build_rejected"),
            (brain_client::AnswerStatus::Unavailable, "unavailable"),
        ] {
            let response = brain_client::PublicAnswerResponse {
                contract_version: brain_client::PUBLIC_API_VERSION.into(),
                request_id: "request-1".into(),
                knowledge_release: "release-1".into(),
                status,
                text: "fixture".into(),
                citations: vec![],
            };
            let value = serde_json::to_value(response).expect("public response must serialize");
            assert_eq!(value["status"], expected);
        }
    }

    #[test]
    fn clap_command_definition_is_valid() {
        Cli::command().debug_assert();
    }

    #[test]
    fn parses_pull_reddit_with_repeated_subreddits_and_gentle_defaults() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "pull",
            "reddit",
            "--subreddit",
            "DeadlockTheGame",
            "--subreddit",
            "DeadlockMemes",
            "--limit",
            "5",
        ])
        .expect("parse cli");

        let Commands::Pull {
            source: PullCommands::Reddit(args),
        } = cli.command
        else {
            panic!("expected pull reddit");
        };
        assert_eq!(
            args.subreddit,
            vec!["DeadlockTheGame".to_string(), "DeadlockMemes".to_string()]
        );
        assert_eq!(args.limit, 5);
        assert_eq!(args.delay_seconds, 2.0);
        assert_eq!(args.cache_ttl_seconds, 86_400);
        assert!(!args.refresh_existing);
    }

    #[test]
    fn parses_parse_reddit_claims_rebuild_flag() {
        let cli = Cli::try_parse_from(["deadlock-brain", "parse", "reddit-claims", "--rebuild"])
            .expect("parse cli");

        let Commands::Parse {
            target: ParseCommands::RedditClaims(args),
        } = cli.command
        else {
            panic!("expected parse reddit-claims");
        };
        assert!(args.rebuild);
    }

    #[test]
    fn parses_player_sync_matches_defaults_hero_to_mo() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "player",
            "sync-matches",
            "123",
            "--cache-ttl-seconds",
            "9",
            "--pretty",
        ])
        .expect("parse cli");

        let Commands::Player {
            target: PlayerCommands::SyncMatches(args),
        } = cli.command
        else {
            panic!("expected player sync-matches");
        };
        assert_eq!(args.account_id, "123");
        assert_eq!(args.hero_id, 18);
        assert_eq!(args.cache_ttl_seconds, 9);
        assert!(args.pretty);
    }

    #[test]
    fn parses_player_fetch_demo_defaults_to_mo_evidence_options() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "player",
            "fetch-demo",
            "123",
            "92685682",
            "--pretty",
        ])
        .expect("parse cli");

        let Commands::Player {
            target: PlayerCommands::FetchDemo(args),
        } = cli.command
        else {
            panic!("expected player fetch-demo");
        };
        assert_eq!(args.account_id, "123");
        assert_eq!(args.match_id, "92685682");
        assert_eq!(args.hero_id, 18);
        assert_eq!(args.steam_id64, 76561198242034120);
        assert_eq!(args.poll_interval_seconds, 5);
        assert_eq!(args.timeout_seconds, 900);
        assert!(args.pretty);
    }

    #[test]
    fn parses_player_analyze_demo_match_flags() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "player",
            "analyze-demo-match",
            "281768392",
            "92685682",
            "--dry-run",
            "--pretty",
        ])
        .expect("parse cli");

        let Commands::Player {
            target: PlayerCommands::AnalyzeDemoMatch(args),
        } = cli.command
        else {
            panic!("expected player analyze-demo-match");
        };
        assert_eq!(args.account_id, "281768392");
        assert_eq!(args.match_id, "92685682");
        assert!(args.dry_run);
        assert!(args.pretty);
    }

    #[test]
    fn parses_player_review_demo_report_file() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "player",
            "review-demo-report",
            "5",
            "--file",
            "/tmp/mo-review.json",
            "--pretty",
        ])
        .expect("parse cli");

        let Commands::Player {
            target: PlayerCommands::ReviewDemoReport(args),
        } = cli.command
        else {
            panic!("expected player review-demo-report");
        };
        assert_eq!(args.note_id, 5);
        assert_eq!(args.file, PathBuf::from("/tmp/mo-review.json"));
        assert!(args.pretty);
    }

    #[test]
    fn parses_player_demo_calibration_status() {
        let cli = Cli::try_parse_from([
            "deadlock-brain",
            "player",
            "demo-calibration-status",
            "281768392",
            "--pretty",
        ])
        .expect("parse cli");

        let Commands::Player {
            target: PlayerCommands::DemoCalibrationStatus(args),
        } = cli.command
        else {
            panic!("expected player demo-calibration-status");
        };
        assert_eq!(args.account_id, "281768392");
        assert!(args.pretty);
    }

    #[test]
    fn player_fetch_demo_metadata_options_are_exact_and_detailed() {
        let args = PlayerFetchDemoArgs {
            account_id: "123".to_string(),
            match_id: "92685682".to_string(),
            hero_id: 18,
            steam_id64: 76561198242034120,
            poll_interval_seconds: 5,
            timeout_seconds: 900,
            pretty: false,
        };

        let options = fetch_demo_match_metadata_options(&args);

        assert_eq!(options.match_ids, ["92685682"]);
        assert_eq!(options.account_ids, ["123"]);
        assert_eq!(options.hero_ids, ["18"]);
        assert!(options.include_player_items);
        assert!(options.include_player_info);
        assert!(options.include_player_stats);
        assert!(options.include_player_death_details);
        assert!(options.include_objectives);
    }

    #[test]
    fn player_fetch_demo_passes_the_metadata_player_slot_to_demo_queries() {
        let args = PlayerFetchDemoArgs {
            account_id: "281768392".to_string(),
            match_id: "92685682".to_string(),
            hero_id: 18,
            steam_id64: 76561198242034120,
            poll_interval_seconds: 5,
            timeout_seconds: 900,
            pretty: false,
        };

        let options =
            fetch_demo_evidence_options(&args, &json!({ "target_player_slot": 8 })).unwrap();

        assert_eq!(options.player_slot, 8);
    }

    #[test]
    fn blocking_http_client_is_built_off_the_async_runtime_thread() {
        use std::{io::Write, net::TcpListener, thread};

        let cache_dir =
            std::env::temp_dir().join(format!("deadlock-brain-http-client-test-{}", process::id()));
        let listener = TcpListener::bind("127.0.0.1:0").expect("listener");
        let url = format!("http://{}/health", listener.local_addr().expect("address"));
        let server = thread::spawn(move || {
            let (mut stream, _) = listener.accept().expect("accept");
            let mut request = [0_u8; 1024];
            let bytes_read = stream.read(&mut request).expect("read request");
            assert!(bytes_read > 0);
            stream
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
                .expect("write response");
        });
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("runtime");

        runtime.block_on(async {
            let client = http_client_async("deadlock-brain-test".to_string(), cache_dir.clone())
                .await
                .expect("blocking http client");
            let response = client
                .get(&url, deadlock_brain_core::http::HttpGetOptions::default())
                .expect("GET inside async command");
            assert_eq!(response.text(), "ok");
            drop(client);
        });
        server.join().expect("server thread");
        fs::remove_dir_all(cache_dir).expect("remove cache dir");
    }

    #[test]
    fn pull_assets_rejects_unsupported_raw_kinds() {
        for kind in ["raw_items", "raw_heroes"] {
            let error = Cli::try_parse_from(["deadlock-brain", "pull", "assets", "--kind", kind])
                .unwrap_err();
            assert_eq!(error.kind(), clap::error::ErrorKind::InvalidValue);
        }
    }

    #[test]
    fn pull_assets_accepts_supported_kinds_and_default() {
        for kind in ["items", "heroes", "ranks"] {
            Cli::try_parse_from(["deadlock-brain", "pull", "assets", "--kind", kind])
                .expect("supported pull assets kind should parse");
        }
        Cli::try_parse_from(["deadlock-brain", "pull", "assets"])
            .expect("pull assets without --kind should parse");
    }

    #[test]
    fn pull_assets_help_lists_supported_kinds_only() {
        let help = Cli::try_parse_from(["deadlock-brain", "pull", "assets", "--help"]).unwrap_err();
        assert_eq!(help.kind(), clap::error::ErrorKind::DisplayHelp);
        let text = help.to_string();
        assert!(text.contains("items"));
        assert!(text.contains("heroes"));
        assert!(!text.contains("raw_items"));
        assert!(!text.contains("raw_heroes"));
    }
}
